import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Megaphone, a as Ticket, b as Clock, c as Sun, d as Shuffle, f as Share2, g as Moon, h as Pause, l as SkipForward, m as Play, n as VolumeX, o as Sunset, p as Radio, r as Volume2, s as Sunrise, t as X, u as SkipBack, v as MapPin, y as Info } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cg9irr2y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var mohallas = [
	{
		id: "chai",
		name: "चाय की चुस्की",
		latin: "Chai Ki Chuski",
		freq: "91.1",
		line: "Tapri ki cutting, bagal wali dukaan ka gossip, aur woh do minute jab duniya mute ho jaati hai.",
		rj: "RJ Adrak",
		city: "Indore",
		horn: "चाय गरम है",
		motif: "steam",
		mood: {
			subah: "Sarafa band, tapri khul gayi. Pehli cutting chal rahi hai.",
			din: "Dhoop tez hai, chai usse tez. Adrak extra.",
			shaam: "Band hone se pehle ek last round. Kulhad garam.",
			raat: "Sarafa ki bheed, steel bench, aur ek free refill."
		},
		programs: [
			{
				title: "Adrak Cut",
				note: "Meethi maangoge, kadak milegi. Aaj kadak hai."
			},
			{
				title: "Tapri Report",
				note: "Bina naam ka gossip. Sirf mohalla jaanta hai."
			},
			{
				title: "Do Minute Ki Chai",
				note: "Break itna hi lamba hai. Pi lo."
			}
		]
	},
	{
		id: "raat",
		name: "रात की बातें",
		latin: "Raat Ki Baatein",
		freq: "94.7",
		line: "Chhat pe chaadar, door kisi ka fan, aur woh baatein jo subah tak yaad nahi rehtin.",
		rj: "RJ Chhat",
		city: "Lucknow",
		horn: "धीरे बोलो",
		motif: "stars",
		mood: {
			subah: "Aakhri sitara. Azaan se pehle wali khamoshi.",
			din: "Raat yahan so rahi hai. Sham ko wapas aana.",
			shaam: "Bijli ki pehli lau. Chat par koi aa gaya.",
			raat: "Thandi hawa, shehar ki door ki roshni, dheemi baat."
		},
		programs: [
			{
				title: "Chhat Session",
				note: "Volume kam. Pados wali neend mein hai."
			},
			{
				title: "Ek Hi Baat",
				note: "Jo din bhar nahi kahi, ab kaho."
			},
			{
				title: "Fan Ki Awaz",
				note: "Background mein sirf hawa. Bas."
			}
		]
	},
	{
		id: "gali",
		name: "गली का रेडियो",
		latin: "Gali Ka Radio",
		freq: "98.3",
		line: "Purana transistor, thodi static, aur woh frequency jo poori gali sunti hai.",
		rj: "RJ Transistor",
		city: "Purani Dilli",
		horn: "गली जाग गई",
		motif: "scan",
		mood: {
			subah: "Doodh wala aa gaya. Radio abhi garam ho raha hai.",
			din: "Dukaan ke bahar speaker. Ek gaana, bees log.",
			shaam: "Andhere se pehle frequency pakad lo.",
			raat: "Static zyada, log kam. Radio phir bhi on hai."
		},
		programs: [
			{
				title: "Static Report",
				note: "Antenna thoda idhar karo. Aa gayi."
			},
			{
				title: "Gali Bulletin",
				note: "Aaj ka halla, seedha speaker se."
			},
			{
				title: "Purana Band",
				note: "Jo set tha, wahi chal raha hai."
			}
		]
	},
	{
		id: "nostalgia",
		name: "थोड़ी सी नॉस्टैल्जिया",
		latin: "Thodi Si Nostalgia",
		freq: "89.6",
		line: "Cassette ka click, woh wali shaam, aur gaana jo ab naam se nahi — scene se yaad aata hai.",
		rj: "RJ Rewind",
		city: "Kolkata",
		horn: "रीवाइंड",
		motif: "dust",
		mood: {
			subah: "Tram ki pehli bell. Chai abhi paper ke saath.",
			din: "Dhoop balcony pe. Koi purani diary khuli padi hai.",
			shaam: "Peeli bulb. Wahi rasta, thoda dheema.",
			raat: "Cassette khatam hone wali hai. Palat do."
		},
		programs: [
			{
				title: "Side B",
				note: "Pencil se likha hua tracklist. Thoda dhundhla."
			},
			{
				title: "Woh Wali Shaam",
				note: "Saal yaad nahi. Mausam yaad hai."
			},
			{
				title: "Rewind",
				note: "Thoda peeche. Wahi line dobara."
			}
		]
	},
	{
		id: "apni",
		name: "अपनी वाली वाइब",
		latin: "Apni Wali Vibe",
		freq: "102.4",
		line: "Koi theme nahi. Aaj jo dil kare — thoda loud, thoda personal, bilkul tumhari.",
		rj: "RJ Apna",
		city: "Goa",
		horn: "अपनी आवाज़",
		motif: "bokeh",
		mood: {
			subah: "Beach khaali. Speaker dheere, chai strong.",
			din: "Dhoop seedhi. Volume apne hisaab se.",
			shaam: "Sky pink ho rahi hai. Mix apna hai.",
			raat: "Lane band, beat khula. Koi dress code nahi."
		},
		programs: [
			{
				title: "Apna Mix",
				note: "Request nahi lete. Yahan sab apna hai."
			},
			{
				title: "No Theme",
				note: "Genre ki tension chhod do."
			},
			{
				title: "Late Check-in",
				note: "Jo aaye, woh line mein hai."
			}
		]
	},
	{
		id: "pink",
		name: "पिंक सिटी",
		latin: "Pink City",
		freq: "93.5",
		line: "Gulabi deewarein, shaam ki dhoop, aur woh chai jo haveli ke saaye mein thandi hoti hai.",
		rj: "RJ Gulabi",
		city: "Jaipur",
		horn: "गुलाल",
		motif: "jali",
		mood: {
			subah: "Deewar abhi thandi hai. Bazaar dheere khul raha hai.",
			din: "Dhoop gulabi. Chhaya dhundho, warna pighal jaoge.",
			shaam: "Sandstone garam. Chai ka round shuru.",
			raat: "Jali ke peeche diya. Shehar dheema, rang abhi bhi."
		},
		programs: [
			{
				title: "Jali Ke Peeche",
				note: "Hawa pattern banati hai. Suno."
			},
			{
				title: "Gulabi Dhoop",
				note: "Shaam ka pehla ghanta. Sabse narm."
			},
			{
				title: "Haveli Hour",
				note: "Aangan khaali hai. Frequency bhari hai."
			}
		]
	},
	{
		id: "baraat",
		name: "बारात का ढोल",
		latin: "Baraat Ka Dhol",
		freq: "106.2",
		line: "Gali band hai, dhol khula hai. Koi invitation nahi — pair khud beat pe aate hain.",
		rj: "RJ Dhol",
		city: "Amritsar",
		horn: "ढोल बजा",
		motif: "bulbs",
		mood: {
			subah: "Kal ki baraat ki thakaan. Dhol abhi bhi kaan mein hai.",
			din: "Tent lag raha hai. Ek side se speaker test.",
			shaam: "Bulb jagmag. Gali ek taraf se band.",
			raat: "Dhol full. Pados teen gali tak sun raha hai."
		},
		programs: [
			{
				title: "Pehla Round",
				note: "Dhol wale ne haath garam kar liye."
			},
			{
				title: "Gali Band",
				note: "Car nahi, sirf pair. Side ho jao."
			},
			{
				title: "Last Song",
				note: "Woh wala, jispe sab line tod dete hain."
			}
		]
	},
	{
		id: "office",
		name: "ऑफिस की चाय",
		latin: "Office Ki Chai",
		freq: "97.1",
		line: "AC ka hum, keyboard ki baarish, aur pantry wali chai jo hamesha thodi zyada ubaali hoti hai.",
		rj: "RJ Cabin",
		city: "Gurugram",
		horn: "मीटिंग है",
		motif: "fluor",
		mood: {
			subah: "Badge scan. Lift mein koi already thaka hua hai.",
			din: "Standup khatam. Asli kaam abhi.",
			shaam: "Floor aadha khaali. Ek aur chai, phir nikalte hain.",
			raat: "Sirf ek cabin jali hai. Deadline ka raag."
		},
		programs: [
			{
				title: "Pantry Break",
				note: "Do minute. Teams pe 'brb' likh do."
			},
			{
				title: "Headphones On",
				note: "Open office. Duniya mute."
			},
			{
				title: "After 7",
				note: "Cafeteria band. Machine abhi chal rahi hai."
			}
		]
	},
	{
		id: "monsoon",
		name: "मानसून गली",
		latin: "Monsoon Gali",
		freq: "95.0",
		line: "Tin shed pe baarish, geeli mitti, aur woh khushboo jispe auto ruk jaata hai.",
		rj: "RJ Baarish",
		city: "Kochi",
		horn: "छतरी भूल गए",
		motif: "rain",
		mood: {
			subah: "Baarish ruk-ruk ke. Chai ke upar lid zaroori.",
			din: "Sadak chamak rahi hai. Paani takle tak.",
			shaam: "Bijli ki lau, phir andhera, phir zor.",
			raat: "Tin pe tap-tap. Neend isi beat pe aayegi."
		},
		programs: [
			{
				title: "Tin Shed",
				note: "Chat pe nahi — chhat ke neeche."
			},
			{
				title: "Geeli Mitti",
				note: "Pehli baarish ka smell, radio pe."
			},
			{
				title: "Ruk Ke Baras",
				note: "Lagta hai ruk gayi. Nahi ruki."
			}
		]
	},
	{
		id: "local",
		name: "लोकल ट्रेन",
		latin: "Local Train",
		freq: "100.2",
		line: "Khidki se guzarta shehar, platform ki beep, aur woh jagah jo ek station ke liye tumhari hai.",
		rj: "RJ Platform",
		city: "Mumbai",
		horn: "अगला स्टेशन",
		motif: "windows",
		mood: {
			subah: "Dhakel narm nahi hoti. Pakad mazboot rakho.",
			din: "Thodi jagah. Khidki wali seat lottery hai.",
			shaam: "Office khatam, dabba bhar gaya. Earphone in.",
			raat: "Last locals. Shehar dheema, track abhi tez."
		},
		programs: [
			{
				title: "Window Seat",
				note: "Agar mili, toh uthna mat."
			},
			{
				title: "Agla Station",
				note: "Naam suno. Utrna ya nahi — decide fast."
			},
			{
				title: "Ladies Side",
				note: "Yahan frequency thodi aur seedhi hai."
			}
		]
	},
	{
		id: "mandir",
		name: "मंदिर की घंटी",
		latin: "Mandir Ki Ghanti",
		freq: "88.8",
		line: "Subah ki pehli ghanti, agarbatti, aur woh khamoshi jo aarti ke baad reh jaati hai.",
		rj: "RJ Ghanti",
		city: "Varanasi",
		horn: "घंटी बजी",
		motif: "glow",
		mood: {
			subah: "Ghat pe pehli lau. Paani abhi kaala, diya naya.",
			din: "Gali garam. Ghanti door se, clear.",
			shaam: "Aarti ki tayyari. Steps pe log ruk rahe hain.",
			raat: "Diyes dheere. Shehar jaagta hai, ghat shaant."
		},
		programs: [
			{
				title: "Pehli Ghanti",
				note: "Ek baar. Phir do. Phir sab."
			},
			{
				title: "Aarti Ke Baad",
				note: "Bheed hati. Hawa mein dhoop nahi, dhuan."
			},
			{
				title: "Ghat FM",
				note: "Naam loud nahi. Bas tone."
			}
		]
	},
	{
		id: "highway",
		name: "हाईवे रात",
		latin: "Highway Raat",
		freq: "104.8",
		line: "Window seat, NH 48, Delhi se Mumbai. Kaanon mein yeh mix, bahar guzarta shehar.",
		rj: "RJ Highway",
		city: "NH 48",
		horn: "हॉर्न ओके",
		motif: "highway",
		mood: {
			subah: "Dhaba dikha. Driver ne indicator lagaya.",
			din: "Dhoop windshield pe. Shehar beech-beech mein.",
			shaam: "Sodium lights shuru. Road lambi ho gayi.",
			raat: "All night, apni wali road par. Seat pakdo."
		},
		programs: [
			{
				title: "Now Boarding",
				note: "Delhi nikal chuka. Agli chai 80 km."
			},
			{
				title: "Khidki Wali",
				note: "Truck ka horn door se aaya, pass hua."
			},
			{
				title: "Dhaba Break",
				note: "Das minute. Gaana band mat karna."
			}
		]
	},
	{
		id: "cricket",
		name: "क्रिकेट गली",
		latin: "Cricket Gali",
		freq: "99.9",
		line: "Maidan nahi mila, toh gali hi ground hai. Ek tennis ball, do ite, aur poora mohalla umpire.",
		rj: "RJ Boundary",
		city: "Meerut",
		horn: "बाउंड्री",
		motif: "flood",
		mood: {
			subah: "Oos hai. Koi nahi aaya. Stumps abhi ghar mein.",
			din: "Dhoop seedhi. Over chhota, chillamchi badi.",
			shaam: "School bag gira, match shuru. Car aayi, toh field in.",
			raat: "Ek bulb, kaafi roshni. Last over bina light ke."
		},
		programs: [
			{
				title: "Last Over",
				note: "Do run chahiye. Gali chhoti hai."
			},
			{
				title: "Car Aayi",
				note: "Field andar. Gaana bhi rukta hai, thodi der."
			},
			{
				title: "Tennis Ball FM",
				note: "Leather nahi. Awaz phir bhi crack ki."
			}
		]
	},
	{
		id: "sardi",
		name: "दिल्ली की सर्दी",
		latin: "Dilli Ki Sardi",
		freq: "92.7",
		line: "Kohra, razai, aur woh seeti jo kisi ke pressure cooker se nahi — hawa se aati hai.",
		rj: "RJ Kohra",
		city: "Delhi",
		horn: "कोहरा गहरा",
		motif: "fog",
		mood: {
			subah: "Saans dikhti hai. Chai dono haathon se.",
			din: "Dhoop mil gayi toh lottery. Nahi mili toh theek.",
			shaam: "Kohra wapas. Streetlight gol-gol.",
			raat: "Razai ke bahar sirf haath. Radio andar."
		},
		programs: [
			{
				title: "Kohra Report",
				note: "Visibility kam. Awaz saaf."
			},
			{
				title: "Razai FM",
				note: "Bahar mat jao. Yahi suno."
			},
			{
				title: "Doosri Chai",
				note: "Pehli khatam. Ketli phir se."
			}
		]
	}
];
var daypartLabel = {
	subah: "Subah",
	din: "Din",
	shaam: "Shaam",
	raat: "Raat"
};
function istHour(ts) {
	const parts = new Intl.DateTimeFormat("en-GB", {
		timeZone: "Asia/Kolkata",
		hour: "2-digit",
		hourCycle: "h23"
	}).formatToParts(ts);
	return Number(parts.find((p) => p.type === "hour")?.value ?? "0");
}
function daypartFromHour(hour) {
	if (hour < 5 || hour >= 19) return "raat";
	if (hour < 11) return "subah";
	if (hour < 16) return "din";
	return "shaam";
}
function formatIst(ts) {
	return new Intl.DateTimeFormat("en-IN", {
		hour: "numeric",
		minute: "2-digit",
		hour12: true,
		timeZone: "Asia/Kolkata"
	}).format(ts);
}
function makeNoise(ctx, kind) {
	const length = ctx.sampleRate * 2;
	const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
	const data = buffer.getChannelData(0);
	let b0 = 0;
	let b1 = 0;
	let b2 = 0;
	let last = 0;
	for (let i = 0; i < length; i++) {
		const white = Math.random() * 2 - 1;
		if (kind === "white") data[i] = white * .4;
		else if (kind === "pink") {
			b0 = .997 * b0 + white * .029;
			b1 = .985 * b1 + white * .032;
			b2 = .95 * b2 + white * .05;
			data[i] = (b0 + b1 + b2) * .22;
		} else {
			last = (last + .02 * white) / 1.02;
			data[i] = last * 3.2;
		}
	}
	return buffer;
}
var Bus = class {
	ctx;
	dest;
	stops = [];
	constructor(ctx, dest) {
		this.ctx = ctx;
		this.dest = dest;
	}
	track(node) {
		this.stops.push(() => {
			try {
				node.disconnect();
			} catch {}
		});
	}
	noise(buffer, gain, filter, lfoHz = 0) {
		const src = this.ctx.createBufferSource();
		src.buffer = buffer;
		src.loop = true;
		const bi = this.ctx.createBiquadFilter();
		bi.type = filter.type;
		bi.frequency.value = filter.freq;
		bi.Q.value = filter.q;
		const g = this.ctx.createGain();
		g.gain.value = gain;
		src.connect(bi);
		bi.connect(g);
		g.connect(this.dest);
		src.start();
		this.stops.push(() => {
			try {
				src.stop();
			} catch {}
		});
		this.track(src);
		this.track(bi);
		this.track(g);
		if (lfoHz > 0) {
			const lfo = this.ctx.createOscillator();
			const depth = this.ctx.createGain();
			lfo.frequency.value = lfoHz;
			depth.gain.value = filter.freq * .22;
			lfo.connect(depth);
			depth.connect(bi.frequency);
			lfo.start();
			this.stops.push(() => {
				try {
					lfo.stop();
				} catch {}
			});
			this.track(lfo);
			this.track(depth);
		}
		return this;
	}
	tone(freq, type, gain, lfoHz = 0, depth = 0) {
		const osc = this.ctx.createOscillator();
		osc.type = type;
		osc.frequency.value = freq;
		const g = this.ctx.createGain();
		g.gain.value = gain;
		osc.connect(g);
		g.connect(this.dest);
		osc.start();
		this.stops.push(() => {
			try {
				osc.stop();
			} catch {}
		});
		this.track(osc);
		this.track(g);
		if (lfoHz > 0) {
			const lfo = this.ctx.createOscillator();
			const amount = this.ctx.createGain();
			lfo.frequency.value = lfoHz;
			amount.gain.value = depth;
			lfo.connect(amount);
			amount.connect(osc.frequency);
			lfo.start();
			this.stops.push(() => {
				try {
					lfo.stop();
				} catch {}
			});
			this.track(lfo);
			this.track(amount);
		}
		return this;
	}
	every(seconds, fire) {
		let alive = true;
		const id = window.setInterval(() => {
			if (!alive) return;
			fire(this.ctx.currentTime + .05);
		}, seconds * 1e3);
		this.stops.push(() => {
			alive = false;
			window.clearInterval(id);
		});
		return this;
	}
	pattern(bpm, steps) {
		const step = 60 / bpm / 2;
		let next = this.ctx.currentTime + .06;
		let i = 0;
		let alive = true;
		const id = window.setInterval(() => {
			if (!alive) return;
			while (next < this.ctx.currentTime + .28) {
				const kind = steps[i % steps.length];
				if (kind === "kick") hitKick(this.ctx, this.dest, next);
				if (kind === "slap") hitSlap(this.ctx, this.dest, next);
				next += step;
				i += 1;
			}
		}, 60);
		this.stops.push(() => {
			alive = false;
			window.clearInterval(id);
		});
		return this;
	}
};
function hitKick(ctx, dest, when) {
	const osc = ctx.createOscillator();
	const g = ctx.createGain();
	osc.type = "sine";
	osc.frequency.setValueAtTime(160, when);
	osc.frequency.exponentialRampToValueAtTime(52, when + .12);
	g.gain.setValueAtTime(1e-4, when);
	g.gain.exponentialRampToValueAtTime(.55, when + .012);
	g.gain.exponentialRampToValueAtTime(1e-4, when + .18);
	osc.connect(g);
	g.connect(dest);
	osc.start(when);
	osc.stop(when + .2);
}
function hitSlap(ctx, dest, when) {
	const length = Math.floor(ctx.sampleRate * .08);
	const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
	const data = buffer.getChannelData(0);
	for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
	const src = ctx.createBufferSource();
	src.buffer = buffer;
	const filter = ctx.createBiquadFilter();
	filter.type = "bandpass";
	filter.frequency.value = 1600;
	filter.Q.value = .7;
	const g = ctx.createGain();
	g.gain.setValueAtTime(.28, when);
	g.gain.exponentialRampToValueAtTime(1e-4, when + .07);
	src.connect(filter);
	filter.connect(g);
	g.connect(dest);
	src.start(when);
	src.stop(when + .08);
}
function chirp(ctx, dest, when, freq) {
	const osc = ctx.createOscillator();
	const g = ctx.createGain();
	osc.type = "sine";
	osc.frequency.setValueAtTime(freq, when);
	osc.frequency.exponentialRampToValueAtTime(freq * 1.15, when + .08);
	g.gain.setValueAtTime(1e-4, when);
	g.gain.exponentialRampToValueAtTime(.03, when + .01);
	g.gain.exponentialRampToValueAtTime(1e-4, when + .12);
	osc.connect(g);
	g.connect(dest);
	osc.start(when);
	osc.stop(when + .14);
}
function bell(ctx, dest, when) {
	[
		523.25,
		659.25,
		783.99,
		1046.5
	].forEach((freq, index) => {
		const osc = ctx.createOscillator();
		const g = ctx.createGain();
		osc.type = "sine";
		osc.frequency.value = freq;
		const peak = .07 / (index + 1);
		g.gain.setValueAtTime(1e-4, when);
		g.gain.exponentialRampToValueAtTime(peak, when + .015);
		g.gain.exponentialRampToValueAtTime(1e-4, when + 2.6);
		osc.connect(g);
		g.connect(dest);
		osc.start(when);
		osc.stop(when + 2.7);
	});
}
function bubble(ctx, dest, when) {
	const osc = ctx.createOscillator();
	const g = ctx.createGain();
	osc.type = "sine";
	const freq = 500 + Math.random() * 700;
	osc.frequency.setValueAtTime(freq, when);
	osc.frequency.exponentialRampToValueAtTime(freq * 1.8, when + .09);
	g.gain.setValueAtTime(1e-4, when);
	g.gain.exponentialRampToValueAtTime(.04, when + .015);
	g.gain.exponentialRampToValueAtTime(1e-4, when + .12);
	osc.connect(g);
	g.connect(dest);
	osc.start(when);
	osc.stop(when + .14);
}
function crack(ctx, dest, when) {
	hitSlap(ctx, dest, when);
	const osc = ctx.createOscillator();
	const g = ctx.createGain();
	osc.type = "triangle";
	osc.frequency.setValueAtTime(180, when);
	osc.frequency.exponentialRampToValueAtTime(70, when + .08);
	g.gain.setValueAtTime(.12, when);
	g.gain.exponentialRampToValueAtTime(1e-4, when + .1);
	osc.connect(g);
	g.connect(dest);
	osc.start(when);
	osc.stop(when + .12);
}
function whistle(ctx, dest, when) {
	const osc = ctx.createOscillator();
	const g = ctx.createGain();
	osc.type = "sine";
	osc.frequency.setValueAtTime(880, when);
	osc.frequency.linearRampToValueAtTime(990, when + .4);
	g.gain.setValueAtTime(1e-4, when);
	g.gain.exponentialRampToValueAtTime(.025, when + .08);
	g.gain.exponentialRampToValueAtTime(1e-4, when + .7);
	osc.connect(g);
	g.connect(dest);
	osc.start(when);
	osc.stop(when + .75);
}
var GaliEngine = class {
	ctx = null;
	master = null;
	bus = null;
	stops = [];
	white = null;
	pink = null;
	brown = null;
	volume = .75;
	playing = false;
	builtFor = null;
	async ensure() {
		if (!this.ctx) {
			const Ctx = window.AudioContext || window.webkitAudioContext;
			this.ctx = new Ctx();
			this.master = this.ctx.createGain();
			this.master.gain.value = .9;
			const comp = this.ctx.createDynamicsCompressor();
			comp.threshold.value = -16;
			comp.knee.value = 18;
			comp.ratio.value = 3.2;
			comp.attack.value = .008;
			comp.release.value = .22;
			this.master.connect(comp);
			comp.connect(this.ctx.destination);
			this.white = makeNoise(this.ctx, "white");
			this.pink = makeNoise(this.ctx, "pink");
			this.brown = makeNoise(this.ctx, "brown");
		}
		if (this.ctx.state === "suspended") await this.ctx.resume();
		return this.ctx;
	}
	async play(id) {
		await this.ensure();
		this.playing = true;
		if (this.builtFor !== id || !this.bus) this.swap(id);
		else this.ramp(this.volume);
	}
	pause() {
		this.playing = false;
		this.ramp(0);
	}
	setStation(id) {
		if (!this.playing || !this.ctx) {
			this.builtFor = null;
			return;
		}
		if (this.builtFor === id) return;
		this.swap(id);
	}
	setVolume(value) {
		this.volume = value;
		if (this.playing) this.ramp(value);
	}
	async horn() {
		const ctx = await this.ensure();
		const when = ctx.currentTime;
		const osc = ctx.createOscillator();
		const filter = ctx.createBiquadFilter();
		const g = ctx.createGain();
		osc.type = "sawtooth";
		osc.frequency.setValueAtTime(240, when);
		osc.frequency.exponentialRampToValueAtTime(80, when + .42);
		filter.type = "lowpass";
		filter.frequency.setValueAtTime(1400, when);
		filter.frequency.exponentialRampToValueAtTime(220, when + .4);
		g.gain.setValueAtTime(1e-4, when);
		g.gain.exponentialRampToValueAtTime(.22, when + .02);
		g.gain.exponentialRampToValueAtTime(1e-4, when + .48);
		osc.connect(filter);
		filter.connect(g);
		g.connect(this.master);
		osc.start(when);
		osc.stop(when + .5);
	}
	ramp(value) {
		if (!this.ctx || !this.bus) return;
		const now = this.ctx.currentTime;
		const current = this.bus.gain.value;
		this.bus.gain.cancelScheduledValues(now);
		this.bus.gain.setValueAtTime(current, now);
		this.bus.gain.linearRampToValueAtTime(value, now + .08);
	}
	swap(id) {
		const ctx = this.ctx;
		const master = this.master;
		if (!ctx || !master || !this.white || !this.pink || !this.brown) return;
		const dying = this.stops;
		const dyingBus = this.bus;
		this.stops = [];
		const next = ctx.createGain();
		next.gain.setValueAtTime(1e-4, ctx.currentTime);
		next.gain.linearRampToValueAtTime(this.playing ? this.volume : 1e-4, ctx.currentTime + .55);
		next.connect(master);
		this.bus = next;
		this.builtFor = id;
		const bed = new Bus(ctx, next);
		voice(id, bed, ctx, next, {
			white: this.white,
			pink: this.pink,
			brown: this.brown
		});
		this.stops = bed.stops;
		if (dyingBus) {
			dyingBus.gain.cancelScheduledValues(ctx.currentTime);
			dyingBus.gain.setValueAtTime(Math.max(dyingBus.gain.value, 1e-4), ctx.currentTime);
			dyingBus.gain.linearRampToValueAtTime(1e-4, ctx.currentTime + .45);
			window.setTimeout(() => {
				dying.forEach((fn) => fn());
				try {
					dyingBus.disconnect();
				} catch {}
			}, 520);
		}
	}
};
function voice(id, bed, ctx, dest, buf) {
	switch (id) {
		case "chai":
			bed.noise(buf.brown, .16, {
				type: "lowpass",
				freq: 180,
				q: .6
			}).noise(buf.pink, .05, {
				type: "bandpass",
				freq: 1300,
				q: .8
			}, .12).tone(196, "sine", .03).every(1.4, (when) => bubble(ctx, dest, when));
			break;
		case "raat":
			bed.tone(196, "sine", .02).tone(392, "sine", .012).noise(buf.brown, .07, {
				type: "lowpass",
				freq: 140,
				q: .5
			}).every(1.1, (when) => chirp(ctx, dest, when, 4200 + Math.random() * 600));
			break;
		case "gali":
			bed.noise(buf.white, .035, {
				type: "bandpass",
				freq: 1800,
				q: 3.2
			}, .4).noise(buf.brown, .12, {
				type: "lowpass",
				freq: 110,
				q: .4
			}).tone(880, "square", .004);
			break;
		case "nostalgia":
			bed.tone(220, "triangle", .04, .25, 6).tone(277.18, "triangle", .018, .18, 4).noise(buf.pink, .045, {
				type: "lowpass",
				freq: 900,
				q: .4
			});
			break;
		case "apni":
			bed.tone(220, "sawtooth", .012).tone(277.18, "sawtooth", .01).tone(329.63, "triangle", .014).noise(buf.pink, .03, {
				type: "lowpass",
				freq: 700,
				q: .6
			}, .5).pattern(100, [
				"kick",
				"rest",
				"slap",
				"rest",
				"kick",
				"slap",
				"rest",
				"slap"
			]);
			break;
		case "pink":
			bed.tone(196, "sine", .03).tone(246.94, "sine", .02).tone(293.66, "triangle", .016).noise(buf.pink, .04, {
				type: "bandpass",
				freq: 640,
				q: .5
			}, .08);
			break;
		case "baraat":
			bed.noise(buf.pink, .05, {
				type: "bandpass",
				freq: 900,
				q: .5
			}, .3).tone(98, "sine", .04).pattern(112, [
				"kick",
				"slap",
				"kick",
				"slap",
				"slap",
				"kick",
				"slap",
				"rest"
			]);
			break;
		case "office":
			bed.tone(60, "sine", .03).tone(120, "sine", .015).noise(buf.white, .012, {
				type: "highpass",
				freq: 5e3,
				q: .4
			}).every(7.5, (when) => chirp(ctx, dest, when, 880));
			break;
		case "monsoon":
			bed.noise(buf.white, .11, {
				type: "bandpass",
				freq: 2200,
				q: .35
			}).noise(buf.brown, .1, {
				type: "lowpass",
				freq: 90,
				q: .4
			}, .08).every(9, (when) => {
				const osc = ctx.createOscillator();
				const g = ctx.createGain();
				osc.type = "sine";
				osc.frequency.setValueAtTime(48, when);
				g.gain.setValueAtTime(1e-4, when);
				g.gain.exponentialRampToValueAtTime(.2, when + .2);
				g.gain.exponentialRampToValueAtTime(1e-4, when + 1.6);
				osc.connect(g);
				g.connect(dest);
				osc.start(when);
				osc.stop(when + 1.7);
			});
			break;
		case "local":
			bed.noise(buf.brown, .14, {
				type: "lowpass",
				freq: 100,
				q: .5
			}).pattern(126, [
				"slap",
				"rest",
				"kick",
				"rest"
			]).every(8, (when) => {
				chirp(ctx, dest, when, 740);
				chirp(ctx, dest, when + .18, 988);
			});
			break;
		case "mandir":
			bed.tone(174.61, "sine", .028).tone(261.63, "sine", .016).noise(buf.brown, .04, {
				type: "lowpass",
				freq: 200,
				q: .4
			}).every(6.5, (when) => bell(ctx, dest, when));
			break;
		case "highway":
			bed.tone(55, "sine", .05).tone(82.4, "triangle", .03).noise(buf.pink, .05, {
				type: "bandpass",
				freq: 480,
				q: .7
			}, .07).noise(buf.white, .02, {
				type: "bandpass",
				freq: 1600,
				q: 1.4
			}, .15);
			break;
		case "cricket":
			bed.noise(buf.pink, .07, {
				type: "bandpass",
				freq: 780,
				q: .6
			}, .25).tone(70, "sine", .02).every(4.2, (when) => {
				if (Math.random() > .35) crack(ctx, dest, when);
			});
			break;
		case "sardi":
			bed.noise(buf.brown, .1, {
				type: "lowpass",
				freq: 220,
				q: .35
			}, .06).tone(311, "sine", .008).every(11, (when) => whistle(ctx, dest, when));
			break;
		default: bed.noise(buf.pink, .05, {
			type: "lowpass",
			freq: 400,
			q: .5
		});
	}
}
var scope = globalThis;
function getEngine() {
	if (!scope.__gali) scope.__gali = new GaliEngine();
	return scope.__gali;
}
var STORAGE_KEY = "gali-radio";
function cn(...parts) {
	return parts.filter(Boolean).join(" ");
}
function RadioGali() {
	const [index, setIndex] = (0, import_react.useState)(0);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [volume, setVolume] = (0, import_react.useState)(.75);
	const [mode, setMode] = (0, import_react.useState)("auto");
	const [sheet, setSheet] = (0, import_react.useState)(null);
	const [now, setNow] = (0, import_react.useState)(null);
	const [horn, setHorn] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [fadeFrom, setFadeFrom] = (0, import_react.useState)(mohallas[0].id);
	const shownRef = (0, import_react.useRef)(mohallas[0].id);
	const indexRef = (0, import_react.useRef)(0);
	const playingRef = (0, import_react.useRef)(false);
	const volumeRef = (0, import_react.useRef)(.75);
	const station = mohallas[index] ?? mohallas[0];
	indexRef.current = index;
	playingRef.current = playing;
	volumeRef.current = volume;
	(0, import_react.useEffect)(() => {
		if (shownRef.current === station.id) return;
		setFadeFrom(shownRef.current);
		shownRef.current = station.id;
		const timer = window.setTimeout(() => setFadeFrom(station.id), 720);
		return () => window.clearTimeout(timer);
	}, [station.id]);
	const hour = now === null ? 21 : istHour(now);
	const part = mode === "auto" ? daypartFromHour(hour) : mode;
	const program = station.programs[now === null ? 0 : Math.floor(now / 45e3) % station.programs.length];
	(0, import_react.useEffect)(() => {
		const fromUrl = new URLSearchParams(window.location.search).get("m");
		let next = mohallas.findIndex((m) => m.id === fromUrl);
		let nextVolume = .75;
		let nextMode = "auto";
		if (next < 0) try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const saved = JSON.parse(raw);
				next = mohallas.findIndex((m) => m.id === saved.id);
				if (typeof saved.volume === "number") nextVolume = saved.volume;
				if (saved.mode) nextMode = saved.mode;
			}
		} catch {}
		if (next >= 0) setIndex(next);
		setVolume(nextVolume);
		setMode(nextMode);
		setReady(true);
		const tick = () => setNow(Date.now());
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify({
			id: station.id,
			volume,
			mode
		}));
		const url = new URL(window.location.href);
		url.searchParams.set("m", station.id);
		window.history.replaceState(null, "", url);
	}, [
		ready,
		station.id,
		volume,
		mode
	]);
	(0, import_react.useEffect)(() => {
		const engine = getEngine();
		engine.setVolume(volume);
		if (playing) engine.setStation(station.id);
	}, [
		station.id,
		playing,
		volume
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const tag = event.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
			if (event.key === "Escape") setSheet(null);
			if (event.key === " ") {
				event.preventDefault();
				togglePlay();
			}
			if (event.key === "ArrowRight" || event.key === "n" || event.key === "N") {
				event.preventDefault();
				step(1);
			}
			if (event.key === "ArrowLeft" || event.key === "p" || event.key === "P") {
				event.preventDefault();
				step(-1);
			}
			if (event.key === "h" || event.key === "H") blowHorn();
			if (event.key === "t" || event.key === "T") setSheet((open) => open === "ticket" ? null : "ticket");
			if (event.key === "q" || event.key === "Q") setSheet((open) => open === "stations" ? null : "stations");
			if (event.key === "m" || event.key === "M") setSheet((open) => open === "mood" ? null : "mood");
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	function step(delta) {
		setIndex((current) => (current + delta + mohallas.length) % mohallas.length);
	}
	function tune(next) {
		setIndex((next + mohallas.length) % mohallas.length);
	}
	async function togglePlay() {
		const engine = getEngine();
		const id = mohallas[indexRef.current]?.id ?? "chai";
		if (playingRef.current) {
			engine.pause();
			setPlaying(false);
			return;
		}
		engine.setVolume(volumeRef.current);
		await engine.play(id);
		setPlaying(true);
	}
	async function blowHorn() {
		const current = mohallas[indexRef.current] ?? mohallas[0];
		setHorn(current.horn);
		window.setTimeout(() => setHorn(null), 900);
		try {
			await getEngine().horn();
		} catch {}
	}
	function surprise() {
		let next = Math.floor(Math.random() * mohallas.length);
		if (next === indexRef.current) next = (next + 1) % mohallas.length;
		setIndex(next);
		setSheet(null);
	}
	async function share() {
		const url = `${window.location.origin}${window.location.pathname}?m=${station.id}`;
		try {
			await navigator.clipboard.writeText(url);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("tone-" + station.id, "relative min-h-dvh overflow-hidden text-cream"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0",
				"aria-hidden": true,
				children: mohallas.filter((item) => item.id === station.id || item.id === fadeFrom).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("world absolute inset-0", "tone-" + item.id, item.id === station.id ? "opacity-100" : "opacity-0"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Motif, { motif: item.motif })
				}, item.id))
			}),
			[
				"subah",
				"din",
				"shaam",
				"raat"
			].map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: cn("pointer-events-none absolute inset-0 transition-opacity duration-700 ease-glide", "veil-" + name, part === name ? "opacity-100" : "opacity-0")
			}, name)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "vignette pointer-events-none absolute inset-0",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				className: "grain pointer-events-none absolute inset-0 size-full",
				"aria-hidden": true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
					id: "gali-grain",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feTurbulence", {
						type: "fractalNoise",
						baseFrequency: "0.85",
						numOctaves: "2",
						stitchTiles: "stitch"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feColorMatrix", {
						type: "saturate",
						values: "0"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "100%",
					height: "100%",
					filter: "url(#gali-grain)"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-4 px-5 pt-5 sm:px-8 sm:pt-7 md:pl-64",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "accent-bg grid size-11 shrink-0 place-items-center rounded-full transition-colors duration-700",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, {
							className: "size-5",
							"aria-hidden": true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl leading-none font-extrabold",
							children: "रेडियो गली"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 text-xs tracking-widest text-cream/60 uppercase",
							children: "Apni gali · Apni frequency"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 text-lg font-medium tabular-nums",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {
							className: "size-4 text-cream/50",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: now === null ? "--:--" : formatIst(now) })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setSheet("mood"),
						className: "text-xs tracking-widest text-cream/70 uppercase transition-opacity hover:text-cream",
						children: [
							mode === "auto" ? "Auto" : daypartLabel[mode],
							" · ",
							daypartLabel[part]
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-20 hidden w-56 flex-col border-r border-cream/10 bg-ink/35 px-3 pt-6 pb-36 backdrop-blur-md md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 pb-3 text-xs tracking-widest text-cream/50 uppercase",
					children: "14 mohalle"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto",
					children: mohallas.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => tune(itemIndex),
						className: cn("rounded-xl px-3 py-2 text-left transition-colors duration-200", item.id === station.id ? "accent-line bg-cream/10" : "hover:bg-cream/5"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-base leading-tight font-bold",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-cream/55",
							children: [
								item.freq,
								" · ",
								item.city
							]
						})]
					}, item.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative z-10 flex min-h-dvh flex-col justify-end px-5 pt-28 pb-44 sm:px-8 md:pl-64 md:pb-40",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm tracking-widest text-cream/70 uppercase",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "accent-text font-semibold",
								children: station.freq
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-2 text-cream/35",
								children: "FM"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: playing ? "Live" : "Ready" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-2 text-cream/35",
								children: "·"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: station.rj })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "rise font-display mt-3 max-w-3xl text-4xl leading-none font-extrabold sm:text-6xl lg:text-7xl",
						children: station.name
					}, station.id),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rise mt-4 max-w-xl text-base leading-relaxed text-cream/80 sm:text-lg",
						children: station.line
					}, station.id + "-line"),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rise mt-6 max-w-xl rounded-2xl border border-cream/15 bg-ink/55 px-4 py-3 backdrop-blur-md",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs tracking-widest text-cream/50 uppercase",
								children: ["Abhi · ", station.city]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display mt-1 text-2xl font-bold",
								children: program.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-cream/75",
								children: program.note
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-cream/60",
								children: station.mood[part]
							})
						]
					}, station.id + program.title)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-cream/10 bg-ink/75 px-4 pt-3 pb-[max(0.85rem,env(safe-area-inset-bottom))] backdrop-blur-xl md:pl-60",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-12 shrink-0 text-xs tracking-widest text-cream/50 uppercase",
									children: "Dial"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "dial",
									type: "range",
									min: 0,
									max: mohallas.length - 1,
									step: 1,
									value: index,
									"aria-label": "Mohalla dial",
									suppressHydrationWarning: true,
									onChange: (event) => tune(Number(event.target.value))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-12 shrink-0 text-right text-sm tabular-nums text-cream/70",
									children: station.freq
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "icon-btn",
											"aria-label": "Pichhla mohalla",
											onClick: () => step(-1),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipBack, { className: "size-5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "accent-bg grid size-14 shrink-0 place-items-center rounded-full transition-transform duration-150 ease-out active:scale-[0.96]",
											"aria-label": playing ? "Roko" : "Chalao",
											onClick: () => void togglePlay(),
											children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5 size-6" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "icon-btn",
											"aria-label": "Agla mohalla",
											onClick: () => step(1),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-5" })
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mx-2 hidden min-w-0 flex-1 items-center gap-2 sm:flex",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": volume === 0 ? "Awaz wapas" : "Mute",
										className: "grid size-11 place-items-center text-cream/70",
										onClick: () => setVolume((value) => value === 0 ? .75 : 0),
										children: volume === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "dial",
										type: "range",
										min: 0,
										max: 1,
										step: .01,
										value: volume,
										"aria-label": "Volume",
										suppressHydrationWarning: true,
										onChange: (event) => {
											const next = Number(event.target.value);
											setVolume(next);
											getEngine().setVolume(next);
										}
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "icon-btn max-sm:hidden",
											"aria-label": "Surprise mohalla",
											onClick: surprise,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "size-5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "icon-btn",
											"aria-label": "Horn",
											onClick: () => void blowHorn(),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "icon-btn",
											"aria-label": "Ticket",
											onClick: () => setSheet("ticket"),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ticket, { className: "size-5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "icon-btn md:hidden",
											"aria-label": "Saare mohalle",
											onClick: () => setSheet("stations"),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "icon-btn",
											"aria-label": "Yeh kaise chalta hai",
											onClick: () => setSheet("about"),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5" })
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "hidden items-center gap-3 text-xs text-cream/45 lg:flex",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kbd, { children: "Space" }),
								" play",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kbd, { children: "←" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kbd, { children: "→" }),
								" mohalla",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kbd, { children: "H" }),
								" horn",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kbd, { children: "T" }),
								" ticket",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kbd, { children: "Q" }),
								" list",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kbd, { children: "M" }),
								" mood",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto",
									children: "Browser mein live mix · gaane host nahi"
								})
							]
						})
					]
				})
			}),
			horn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "horn-flash pointer-events-none fixed inset-0 z-40 grid place-items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display px-6 text-center text-6xl font-extrabold text-cream sm:text-8xl",
					children: horn
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: sheet !== null,
				label: "Radio Gali panel",
				onClose: () => setSheet(null),
				children: [
					sheet === "stations" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
						title: "Saare mohalle",
						sub: "Apna scene chuno. Dial bhi wahi kaam karti hai."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-2",
						children: mohallas.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								tune(itemIndex);
								setSheet(null);
							},
							className: cn("flex w-full items-center justify-between gap-3 rounded-2xl px-3 py-3 text-left", item.id === station.id ? "bg-cream/10" : "hover:bg-cream/5"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display block text-lg font-bold",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-cream/60",
								children: [
									item.city,
									" · ",
									item.latin
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "accent-text text-sm tabular-nums",
								children: item.freq
							})]
						}) }, item.id))
					})] }) : null,
					sheet === "ticket" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketCard, {
						station,
						part,
						now
					}) : null,
					sheet === "mood" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoodBoard, {
						mode,
						part,
						onMode: setMode,
						onCity: (id) => {
							const next = mohallas.findIndex((item) => item.id === id);
							if (next >= 0) tune(next);
							setSheet(null);
						}
					}) : null,
					sheet === "about" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {
						copied,
						onShare: () => void share(),
						onSurprise: surprise
					}) : null
				]
			})
		]
	});
}
function Kbd({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
		className: "rounded-md border border-cream/20 px-1.5 py-0.5 font-sans text-xs text-cream/70",
		children
	});
}
function SheetTitle({ title, sub }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-display text-3xl font-extrabold",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-sm leading-relaxed text-cream/65",
		children: sub
	})] });
}
function Sheet({ open, label, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("fixed inset-0 z-40 flex items-end justify-center transition-opacity duration-300 ease-glide", open ? "opacity-100" : "pointer-events-none opacity-0"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Band karo",
			className: "absolute inset-0 bg-ink/70 backdrop-blur-sm",
			onClick: onClose,
			tabIndex: open ? 0 : -1
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": label,
			inert: !open,
			className: cn("relative max-h-[min(78dvh,40rem)] w-full max-w-md overflow-y-auto rounded-t-3xl border border-cream/15 bg-ink/92 px-5 pt-3 pb-8 shadow-2xl transition-transform duration-500 ease-glide", open ? "translate-y-0" : "translate-y-full"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1 w-10 rounded-full bg-cream/30" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					"aria-label": "Sheet band karo",
					className: "absolute top-4 right-4 grid size-11 place-items-center rounded-full text-cream/70 hover:text-cream",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				}),
				children
			]
		})]
	});
}
function TicketCard({ station, part, now }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
		title: "Boarding pass",
		sub: "Is mohalle ka ticket. Khidki wali seat."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mt-5 rounded-2xl bg-cream px-5 py-5 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-ink/50 uppercase",
				children: "Radio Gali · Window seat"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display mt-2 text-4xl leading-none font-extrabold",
				children: station.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-ink/70",
				children: station.latin
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-5 grid grid-cols-2 gap-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs tracking-widest text-ink/45 uppercase",
						children: "Frequency"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 text-lg font-semibold",
						children: [station.freq, " FM"]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs tracking-widest text-ink/45 uppercase",
						children: "Shehar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-lg font-semibold",
						children: station.city
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs tracking-widest text-ink/45 uppercase",
						children: "Waqt"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 text-lg font-semibold",
						children: [daypartLabel[part], now ? ` · ${formatIst(now)}` : ""]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs tracking-widest text-ink/45 uppercase",
						children: "RJ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-lg font-semibold",
						children: station.rj
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 border-t border-dashed border-ink/20 pt-4 text-sm leading-relaxed",
				children: "Life thodi loud hai? Apni gali tune karo. Baaki sab background noise hai."
			})
		]
	})] });
}
var modes = [
	{
		id: "auto",
		label: "Auto",
		icon: Clock
	},
	{
		id: "subah",
		label: "Subah",
		icon: Sunrise
	},
	{
		id: "din",
		label: "Din",
		icon: Sun
	},
	{
		id: "shaam",
		label: "Shaam",
		icon: Sunset
	},
	{
		id: "raat",
		label: "Raat",
		icon: Moon
	}
];
function MoodBoard({ mode, part, onMode, onCity }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
			title: "India ka mood",
			sub: "Shehar chuno. Scene ka rang waqt ke saath badlega — subah se raat tak."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid grid-cols-5 gap-2",
			children: modes.map((item) => {
				const Icon = item.icon;
				const active = mode === item.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onMode(item.id),
					className: cn("flex h-16 flex-col items-center justify-center gap-1 rounded-xl text-xs", active ? "accent-bg" : "bg-cream/10 text-cream"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-4",
						"aria-hidden": true
					}), item.label]
				}, item.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 flex flex-col",
			children: mohallas.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "border-t border-cream/10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onCity(item.id),
					className: "flex w-full items-start gap-3 py-3 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
						className: "mt-0.5 size-4 shrink-0 text-cream/50",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block font-medium",
						children: [item.city, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 text-cream/45",
							children: item.latin
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 block text-sm leading-relaxed text-cream/65",
						children: item.mood[part]
					})] })]
				})
			}, item.id))
		})
	] });
}
function About({ copied, onShare, onSurprise }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
			title: "Bas tap karo.",
			sub: "Yeh sound playground hai. Koi account nahi. Awaz tumhare browser mein banti hai — gaane host nahi karte."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
			className: "mt-5 flex flex-col gap-3 text-sm leading-relaxed",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "accent-text font-semibold",
					children: "01 "
				}), "Mohalla chuno — dial, list, ya shehar."] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "accent-text font-semibold",
					children: "02 "
				}), "Play dabao. Volume apne hisaab se."] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "accent-text font-semibold",
					children: "03 "
				}), "Horn, ticket, ya seedha doosri gali."] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onSurprise,
				className: "accent-bg h-12 rounded-full text-sm font-semibold transition-transform duration-150 active:scale-[0.96]",
				children: "Surprise mohalla"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onShare,
				className: "flex h-12 items-center justify-center gap-2 rounded-full border border-cream/20 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {
					className: "size-4",
					"aria-hidden": true
				}), copied ? "Link copy ho gaya" : "Is frequency ko share karo"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 border-t border-cream/10 pt-4 text-sm leading-relaxed text-cream/70",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Agar Hindi gaane chahiye, woh Spotify par hain — account tumhara, playback unka." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 flex flex-col gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "underline decoration-cream/30 underline-offset-4",
						href: "https://open.spotify.com/playlist/1Iqn0mNNTSBFPTrgPY0e1j",
						target: "_blank",
						rel: "noreferrer",
						children: "Hindi hits · non-stop"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "underline decoration-cream/30 underline-offset-4",
						href: "https://open.spotify.com/playlist/0I6mu7LlHfxuCKx7yevUGr",
						target: "_blank",
						rel: "noreferrer",
						children: "Top Bollywood 2026"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-cream/80",
					children: "Main yeh gali chalata hoon. Har mohalle ki awaaz yahin set hoti hai. Naye scene judte rahenge."
				})
			]
		})
	] });
}
function Motif({ motif }) {
	if (motif === "steam") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "steam absolute inset-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
				left: "18%",
				animationDelay: "0s"
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
				left: "48%",
				animationDelay: "1.2s"
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
				left: "72%",
				animationDelay: "2.1s"
			} })
		]
	});
	if (motif === "stars") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "stars absolute inset-0",
		children: [
			["12%", "18%"],
			["28%", "32%"],
			["46%", "14%"],
			["63%", "26%"],
			["78%", "12%"],
			["88%", "34%"],
			["20%", "48%"],
			["70%", "46%"]
		].map(([left, top], star) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
			left,
			top,
			animationDelay: `${star * .35}s`
		} }, star))
	});
	if (motif === "scan") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scanlines absolute inset-0" });
	if (motif === "dust") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "dust absolute inset-0",
		children: [
			"10%",
			"24%",
			"40%",
			"58%",
			"73%",
			"86%"
		].map((left, bit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
			left,
			animationDelay: `${bit * 1.3}s`,
			animationDuration: `${9 + bit}s`
		} }, left))
	});
	if (motif === "bokeh") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bokeh absolute inset-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
				width: "28vw",
				height: "28vw",
				left: "8%",
				top: "18%"
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
				width: "18vw",
				height: "18vw",
				right: "10%",
				top: "30%",
				animationDelay: "1s"
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
				width: "22vw",
				height: "22vw",
				left: "40%",
				bottom: "18%",
				animationDelay: "0.4s"
			} })
		]
	});
	if (motif === "jali") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "jali absolute inset-0" });
	if (motif === "bulbs") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bulbs absolute inset-x-0 top-0",
		children: Array.from({ length: 12 }, (_, bulb) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}, bulb))
	});
	if (motif === "fluor") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "fluor absolute inset-0" });
	if (motif === "rain") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rain absolute inset-0" });
	if (motif === "windows") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-x-0 top-[18%] overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "windows",
			children: Array.from({ length: 8 }, (_, pane) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}, pane))
		})
	});
	if (motif === "glow") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 grid place-items-end justify-center pb-[18%]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "diya" })
	});
	if (motif === "highway") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "streaks absolute inset-x-0 top-[22%]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
				top: "10%",
				animationDelay: "0s"
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
				top: "38%",
				animationDelay: "0.8s",
				width: "18vw"
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
				top: "64%",
				animationDelay: "1.4s"
			} })
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "road absolute inset-x-0" })] });
	if (motif === "flood") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flood absolute inset-0" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "fog absolute inset-0" });
}
var SplitComponent = RadioGali;
//#endregion
export { SplitComponent as component };
