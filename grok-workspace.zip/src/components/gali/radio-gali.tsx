import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  Clock,
  Info,
  MapPin,
  Megaphone,
  Moon,
  Pause,
  Play,
  Radio,
  Share2,
  Shuffle,
  SkipBack,
  SkipForward,
  Sun,
  Sunrise,
  Sunset,
  Ticket,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import {
  daypartFromHour,
  daypartLabel,
  formatIst,
  istHour,
  mohallas,
  type Daypart,
  type Mohalla,
  type Motif,
} from "@/data/mohallas";
import { getEngine } from "@/lib/radio-audio";

type Sheet = null | "stations" | "ticket" | "mood" | "about";
type DayMode = "auto" | Daypart;

const STORAGE_KEY = "gali-radio";

function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function RadioGali() {
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.75);
  const [mode, setMode] = useState<DayMode>("auto");
  const [sheet, setSheet] = useState<Sheet>(null);
  const [now, setNow] = useState<number | null>(null);
  const [horn, setHorn] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [ready, setReady] = useState(false);
  const [fadeFrom, setFadeFrom] = useState(mohallas[0].id);
  const shownRef = useRef(mohallas[0].id);
  const indexRef = useRef(0);
  const playingRef = useRef(false);
  const volumeRef = useRef(0.75);
  const station = mohallas[index] ?? mohallas[0];
  indexRef.current = index;
  playingRef.current = playing;
  volumeRef.current = volume;

  useEffect(() => {
    if (shownRef.current === station.id) return;
    setFadeFrom(shownRef.current);
    shownRef.current = station.id;
    const timer = window.setTimeout(() => setFadeFrom(station.id), 720);
    return () => window.clearTimeout(timer);
  }, [station.id]);

  const hour = now === null ? 21 : istHour(now);
  const part: Daypart = mode === "auto" ? daypartFromHour(hour) : mode;
  const program =
    station.programs[
      now === null ? 0 : Math.floor(now / 45000) % station.programs.length
    ];

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const fromUrl = params.get("m");
    let next = mohallas.findIndex((m) => m.id === fromUrl);
    let nextVolume = 0.75;
    let nextMode: DayMode = "auto";
    if (next < 0) {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
          const saved = JSON.parse(raw) as {
            id?: string;
            volume?: number;
            mode?: DayMode;
          };
          next = mohallas.findIndex((m) => m.id === saved.id);
          if (typeof saved.volume === "number") nextVolume = saved.volume;
          if (saved.mode) nextMode = saved.mode;
        }
      } catch {
        /* ignore broken storage */
      }
    }
    if (next >= 0) setIndex(next);
    setVolume(nextVolume);
    setMode(nextMode);
    setReady(true);
    const tick = () => setNow(Date.now());
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ id: station.id, volume, mode }),
    );
    const url = new URL(window.location.href);
    url.searchParams.set("m", station.id);
    window.history.replaceState(null, "", url);
  }, [ready, station.id, volume, mode]);

  useEffect(() => {
    const engine = getEngine();
    engine.setVolume(volume);
    if (playing) engine.setStation(station.id);
  }, [station.id, playing, volume]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (event.key === "Escape") setSheet(null);
      if (event.key === " ") {
        event.preventDefault();
        void togglePlay();
      }
      if (event.key === "ArrowRight" || event.key === "n" || event.key === "N") {
        event.preventDefault();
        step(1);
      }
      if (event.key === "ArrowLeft" || event.key === "p" || event.key === "P") {
        event.preventDefault();
        step(-1);
      }
      if (event.key === "h" || event.key === "H") void blowHorn();
      if (event.key === "t" || event.key === "T")
        setSheet((open) => (open === "ticket" ? null : "ticket"));
      if (event.key === "q" || event.key === "Q")
        setSheet((open) => (open === "stations" ? null : "stations"));
      if (event.key === "m" || event.key === "M")
        setSheet((open) => (open === "mood" ? null : "mood"));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function step(delta: number) {
    setIndex((current) => (current + delta + mohallas.length) % mohallas.length);
  }

  function tune(next: number) {
    setIndex((next + mohallas.length) % mohallas.length);
  }

  async function togglePlay() {
    const engine = getEngine();
    const id = mohallas[indexRef.current]?.id ?? "chai";
    if (playingRef.current) {
      engine.pause();
      setPlaying(false);
      return;
    }
    engine.setVolume(volumeRef.current);
    await engine.play(id);
    setPlaying(true);
  }

  async function blowHorn() {
    const current = mohallas[indexRef.current] ?? mohallas[0];
    setHorn(current.horn);
    window.setTimeout(() => setHorn(null), 900);
    try {
      await getEngine().horn();
    } catch {
      /* audio can fail before a gesture on some browsers */
    }
  }

  function surprise() {
    let next = Math.floor(Math.random() * mohallas.length);
    if (next === indexRef.current) next = (next + 1) % mohallas.length;
    setIndex(next);
    setSheet(null);
  }

  async function share() {
    const url = `${window.location.origin}${window.location.pathname}?m=${station.id}`;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className={cn("tone-" + station.id, "relative min-h-dvh overflow-hidden text-cream")}>
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        {mohallas
          .filter((item) => item.id === station.id || item.id === fadeFrom)
          .map((item) => (
          <div
            key={item.id}
            className={cn(
              "world absolute inset-0",
              "tone-" + item.id,
              item.id === station.id ? "opacity-100" : "opacity-0",
            )}
          >
            <Motif motif={item.motif} />
          </div>
        ))}
      </div>
      {(["subah", "din", "shaam", "raat"] as const).map((name) => (
        <div
          key={name}
          aria-hidden
          className={cn(
            "pointer-events-none absolute inset-0 transition-opacity duration-700 ease-glide",
            "veil-" + name,
            part === name ? "opacity-100" : "opacity-0",
          )}
        />
      ))}
      <div className="vignette pointer-events-none absolute inset-0" aria-hidden />
      <svg className="grain pointer-events-none absolute inset-0 size-full" aria-hidden>
        <filter id="gali-grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#gali-grain)" />
      </svg>

      <header className="absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-4 px-5 pt-5 sm:px-8 sm:pt-7 md:pl-64">
        <div className="flex items-center gap-3">
          <span className="accent-bg grid size-11 shrink-0 place-items-center rounded-full transition-colors duration-700">
            <Radio className="size-5" aria-hidden />
          </span>
          <span className="flex flex-col">
            <span className="font-display text-xl leading-none font-extrabold">रेडियो गली</span>
            <span className="mt-1 text-xs tracking-widest text-cream/60 uppercase">
              Apni gali · Apni frequency
            </span>
          </span>
        </div>
        <div className="flex flex-col items-end gap-2">
          <p className="flex items-center gap-2 text-lg font-medium tabular-nums">
            <Clock className="size-4 text-cream/50" aria-hidden />
            <span>{now === null ? "--:--" : formatIst(now)}</span>
          </p>
          <button
            type="button"
            onClick={() => setSheet("mood")}
            className="text-xs tracking-widest text-cream/70 uppercase transition-opacity hover:text-cream"
          >
            {mode === "auto" ? "Auto" : daypartLabel[mode]} · {daypartLabel[part]}
          </button>
        </div>
      </header>

      <aside className="fixed inset-y-0 left-0 z-20 hidden w-56 flex-col border-r border-cream/10 bg-ink/35 px-3 pt-6 pb-36 backdrop-blur-md md:flex">
        <p className="px-3 pb-3 text-xs tracking-widest text-cream/50 uppercase">14 mohalle</p>
        <div className="flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto">
          {mohallas.map((item, itemIndex) => (
            <button
              key={item.id}
              type="button"
              onClick={() => tune(itemIndex)}
              className={cn(
                "rounded-xl px-3 py-2 text-left transition-colors duration-200",
                item.id === station.id ? "accent-line bg-cream/10" : "hover:bg-cream/5",
              )}
            >
              <span className="block font-display text-base leading-tight font-bold">
                {item.name}
              </span>
              <span className="text-xs text-cream/55">
                {item.freq} · {item.city}
              </span>
            </button>
          ))}
        </div>
      </aside>

      <main className="relative z-10 flex min-h-dvh flex-col justify-end px-5 pt-28 pb-44 sm:px-8 md:pl-64 md:pb-40">
        <p className="text-sm tracking-widest text-cream/70 uppercase">
          <span className="accent-text font-semibold">{station.freq}</span>
          <span className="px-2 text-cream/35">FM</span>
          <span>{playing ? "Live" : "Ready"}</span>
          <span className="px-2 text-cream/35">·</span>
          <span>{station.rj}</span>
        </p>
        <h1
          key={station.id}
          className="rise font-display mt-3 max-w-3xl text-4xl leading-none font-extrabold sm:text-6xl lg:text-7xl"
        >
          {station.name}
        </h1>
        <p key={station.id + "-line"} className="rise mt-4 max-w-xl text-base leading-relaxed text-cream/80 sm:text-lg">
          {station.line}
        </p>
        <div
          key={station.id + program.title}
          className="rise mt-6 max-w-xl rounded-2xl border border-cream/15 bg-ink/55 px-4 py-3 backdrop-blur-md"
        >
          <p className="text-xs tracking-widest text-cream/50 uppercase">Abhi · {station.city}</p>
          <p className="font-display mt-1 text-2xl font-bold">{program.title}</p>
          <p className="mt-1 text-sm leading-relaxed text-cream/75">{program.note}</p>
          <p className="mt-3 text-sm text-cream/60">{station.mood[part]}</p>
        </div>
      </main>

      <footer className="fixed inset-x-0 bottom-0 z-30 border-t border-cream/10 bg-ink/75 px-4 pt-3 pb-[max(0.85rem,env(safe-area-inset-bottom))] backdrop-blur-xl md:pl-60">
        <div className="mx-auto flex max-w-3xl flex-col gap-2">
          <label className="flex items-center gap-3">
            <span className="w-12 shrink-0 text-xs tracking-widest text-cream/50 uppercase">Dial</span>
            <input
              className="dial"
              type="range"
              min={0}
              max={mohallas.length - 1}
              step={1}
              value={index}
              aria-label="Mohalla dial"
              suppressHydrationWarning
              onChange={(event) => tune(Number(event.target.value))}
            />
            <span className="w-12 shrink-0 text-right text-sm tabular-nums text-cream/70">
              {station.freq}
            </span>
          </label>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1">
              <button type="button" className="icon-btn" aria-label="Pichhla mohalla" onClick={() => step(-1)}>
                <SkipBack className="size-5" />
              </button>
              <button
                type="button"
                className="accent-bg grid size-14 shrink-0 place-items-center rounded-full transition-transform duration-150 ease-out active:scale-[0.96]"
                aria-label={playing ? "Roko" : "Chalao"}
                onClick={() => void togglePlay()}
              >
                {playing ? <Pause className="size-6" /> : <Play className="ml-0.5 size-6" />}
              </button>
              <button type="button" className="icon-btn" aria-label="Agla mohalla" onClick={() => step(1)}>
                <SkipForward className="size-5" />
              </button>
            </div>
            <label className="mx-2 hidden min-w-0 flex-1 items-center gap-2 sm:flex">
              <button
                type="button"
                aria-label={volume === 0 ? "Awaz wapas" : "Mute"}
                className="grid size-11 place-items-center text-cream/70"
                onClick={() => setVolume((value) => (value === 0 ? 0.75 : 0))}
              >
                {volume === 0 ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
              </button>
              <input
                className="dial"
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={volume}
                aria-label="Volume"
                suppressHydrationWarning
                onChange={(event) => {
                  const next = Number(event.target.value);
                  setVolume(next);
                  getEngine().setVolume(next);
                }}
              />
            </label>
            <div className="flex items-center gap-1">
              <button
                type="button"
                className="icon-btn max-sm:hidden"
                aria-label="Surprise mohalla"
                onClick={surprise}
              >
                <Shuffle className="size-5" />
              </button>
              <button type="button" className="icon-btn" aria-label="Horn" onClick={() => void blowHorn()}>
                <Megaphone className="size-5" />
              </button>
              <button type="button" className="icon-btn" aria-label="Ticket" onClick={() => setSheet("ticket")}>
                <Ticket className="size-5" />
              </button>
              <button
                type="button"
                className="icon-btn md:hidden"
                aria-label="Saare mohalle"
                onClick={() => setSheet("stations")}
              >
                <Radio className="size-5" />
              </button>
              <button type="button" className="icon-btn" aria-label="Yeh kaise chalta hai" onClick={() => setSheet("about")}>
                <Info className="size-5" />
              </button>
            </div>
          </div>
          <p className="hidden items-center gap-3 text-xs text-cream/45 lg:flex">
            <Kbd>Space</Kbd> play
            <Kbd>←</Kbd>
            <Kbd>→</Kbd> mohalla
            <Kbd>H</Kbd> horn
            <Kbd>T</Kbd> ticket
            <Kbd>Q</Kbd> list
            <Kbd>M</Kbd> mood
            <span className="ml-auto">Browser mein live mix · gaane host nahi</span>
          </p>
        </div>
      </footer>

      {horn ? (
        <div className="horn-flash pointer-events-none fixed inset-0 z-40 grid place-items-center">
          <p className="font-display px-6 text-center text-6xl font-extrabold text-cream sm:text-8xl">
            {horn}
          </p>
        </div>
      ) : null}

      <Sheet open={sheet !== null} label="Radio Gali panel" onClose={() => setSheet(null)}>
        {sheet === "stations" ? (
          <div>
            <SheetTitle title="Saare mohalle" sub="Apna scene chuno. Dial bhi wahi kaam karti hai." />
            <ul className="mt-4 flex flex-col gap-2">
              {mohallas.map((item, itemIndex) => (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => {
                      tune(itemIndex);
                      setSheet(null);
                    }}
                    className={cn(
                      "flex w-full items-center justify-between gap-3 rounded-2xl px-3 py-3 text-left",
                      item.id === station.id ? "bg-cream/10" : "hover:bg-cream/5",
                    )}
                  >
                    <span>
                      <span className="font-display block text-lg font-bold">{item.name}</span>
                      <span className="text-sm text-cream/60">
                        {item.city} · {item.latin}
                      </span>
                    </span>
                    <span className="accent-text text-sm tabular-nums">{item.freq}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
        {sheet === "ticket" ? <TicketCard station={station} part={part} now={now} /> : null}
        {sheet === "mood" ? (
          <MoodBoard
            mode={mode}
            part={part}
            onMode={setMode}
            onCity={(id) => {
              const next = mohallas.findIndex((item) => item.id === id);
              if (next >= 0) tune(next);
              setSheet(null);
            }}
          />
        ) : null}
        {sheet === "about" ? (
          <About copied={copied} onShare={() => void share()} onSurprise={surprise} />
        ) : null}
      </Sheet>
    </div>
  );
}

function Kbd({ children }: { children: string }) {
  return (
    <kbd className="rounded-md border border-cream/20 px-1.5 py-0.5 font-sans text-xs text-cream/70">
      {children}
    </kbd>
  );
}

function SheetTitle({ title, sub }: { title: string; sub: string }) {
  return (
    <div>
      <h2 className="font-display text-3xl font-extrabold">{title}</h2>
      <p className="mt-1 text-sm leading-relaxed text-cream/65">{sub}</p>
    </div>
  );
}

function Sheet({
  open,
  label,
  onClose,
  children,
}: {
  open: boolean;
  label: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div
      className={cn(
        "fixed inset-0 z-40 flex items-end justify-center transition-opacity duration-300 ease-glide",
        open ? "opacity-100" : "pointer-events-none opacity-0",
      )}
    >
      <button
        type="button"
        aria-label="Band karo"
        className="absolute inset-0 bg-ink/70 backdrop-blur-sm"
        onClick={onClose}
        tabIndex={open ? 0 : -1}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={label}
        inert={!open}
        className={cn(
          "relative max-h-[min(78dvh,40rem)] w-full max-w-md overflow-y-auto rounded-t-3xl border border-cream/15 bg-ink/92 px-5 pt-3 pb-8 shadow-2xl transition-transform duration-500 ease-glide",
          open ? "translate-y-0" : "translate-y-full",
        )}
      >
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-cream/30" />
        <button
          type="button"
          onClick={onClose}
          aria-label="Sheet band karo"
          className="absolute top-4 right-4 grid size-11 place-items-center rounded-full text-cream/70 hover:text-cream"
        >
          <X className="size-5" />
        </button>
        {children}
      </div>
    </div>
  );
}

function TicketCard({
  station,
  part,
  now,
}: {
  station: Mohalla;
  part: Daypart;
  now: number | null;
}) {
  return (
    <div>
      <SheetTitle title="Boarding pass" sub="Is mohalle ka ticket. Khidki wali seat." />
      <article className="mt-5 rounded-2xl bg-cream px-5 py-5 text-ink">
        <p className="text-xs tracking-widest text-ink/50 uppercase">Radio Gali · Window seat</p>
        <h3 className="font-display mt-2 text-4xl leading-none font-extrabold">{station.name}</h3>
        <p className="mt-1 text-sm text-ink/70">{station.latin}</p>
        <dl className="mt-5 grid grid-cols-2 gap-4 text-sm">
          <div>
            <dt className="text-xs tracking-widest text-ink/45 uppercase">Frequency</dt>
            <dd className="mt-1 text-lg font-semibold">{station.freq} FM</dd>
          </div>
          <div>
            <dt className="text-xs tracking-widest text-ink/45 uppercase">Shehar</dt>
            <dd className="mt-1 text-lg font-semibold">{station.city}</dd>
          </div>
          <div>
            <dt className="text-xs tracking-widest text-ink/45 uppercase">Waqt</dt>
            <dd className="mt-1 text-lg font-semibold">
              {daypartLabel[part]}
              {now ? ` · ${formatIst(now)}` : ""}
            </dd>
          </div>
          <div>
            <dt className="text-xs tracking-widest text-ink/45 uppercase">RJ</dt>
            <dd className="mt-1 text-lg font-semibold">{station.rj}</dd>
          </div>
        </dl>
        <p className="mt-5 border-t border-dashed border-ink/20 pt-4 text-sm leading-relaxed">
          Life thodi loud hai? Apni gali tune karo. Baaki sab background noise hai.
        </p>
      </article>
    </div>
  );
}

const modes: Array<{ id: DayMode; label: string; icon: typeof Sun }> = [
  { id: "auto", label: "Auto", icon: Clock },
  { id: "subah", label: "Subah", icon: Sunrise },
  { id: "din", label: "Din", icon: Sun },
  { id: "shaam", label: "Shaam", icon: Sunset },
  { id: "raat", label: "Raat", icon: Moon },
];

function MoodBoard({
  mode,
  part,
  onMode,
  onCity,
}: {
  mode: DayMode;
  part: Daypart;
  onMode: (mode: DayMode) => void;
  onCity: (id: string) => void;
}) {
  return (
    <div>
      <SheetTitle
        title="India ka mood"
        sub="Shehar chuno. Scene ka rang waqt ke saath badlega — subah se raat tak."
      />
      <div className="mt-4 grid grid-cols-5 gap-2">
        {modes.map((item) => {
          const Icon = item.icon;
          const active = mode === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onMode(item.id)}
              className={cn(
                "flex h-16 flex-col items-center justify-center gap-1 rounded-xl text-xs",
                active ? "accent-bg" : "bg-cream/10 text-cream",
              )}
            >
              <Icon className="size-4" aria-hidden />
              {item.label}
            </button>
          );
        })}
      </div>
      <ul className="mt-4 flex flex-col">
        {mohallas.map((item) => (
          <li key={item.id} className="border-t border-cream/10">
            <button
              type="button"
              onClick={() => onCity(item.id)}
              className="flex w-full items-start gap-3 py-3 text-left"
            >
              <MapPin className="mt-0.5 size-4 shrink-0 text-cream/50" aria-hidden />
              <span>
                <span className="block font-medium">
                  {item.city}
                  <span className="ml-2 text-cream/45">{item.latin}</span>
                </span>
                <span className="mt-0.5 block text-sm leading-relaxed text-cream/65">
                  {item.mood[part]}
                </span>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function About({
  copied,
  onShare,
  onSurprise,
}: {
  copied: boolean;
  onShare: () => void;
  onSurprise: () => void;
}) {
  return (
    <div>
      <SheetTitle
        title="Bas tap karo."
        sub="Yeh sound playground hai. Koi account nahi. Awaz tumhare browser mein banti hai — gaane host nahi karte."
      />
      <ol className="mt-5 flex flex-col gap-3 text-sm leading-relaxed">
        <li>
          <span className="accent-text font-semibold">01 </span>
          Mohalla chuno — dial, list, ya shehar.
        </li>
        <li>
          <span className="accent-text font-semibold">02 </span>
          Play dabao. Volume apne hisaab se.
        </li>
        <li>
          <span className="accent-text font-semibold">03 </span>
          Horn, ticket, ya seedha doosri gali.
        </li>
      </ol>
      <div className="mt-5 flex flex-col gap-2">
        <button
          type="button"
          onClick={onSurprise}
          className="accent-bg h-12 rounded-full text-sm font-semibold transition-transform duration-150 active:scale-[0.96]"
        >
          Surprise mohalla
        </button>
        <button
          type="button"
          onClick={onShare}
          className="flex h-12 items-center justify-center gap-2 rounded-full border border-cream/20 text-sm"
        >
          <Share2 className="size-4" aria-hidden />
          {copied ? "Link copy ho gaya" : "Is frequency ko share karo"}
        </button>
      </div>
      <div className="mt-6 border-t border-cream/10 pt-4 text-sm leading-relaxed text-cream/70">
        <p>Agar Hindi gaane chahiye, woh Spotify par hain — account tumhara, playback unka.</p>
        <p className="mt-2 flex flex-col gap-1">
          <a
            className="underline decoration-cream/30 underline-offset-4"
            href="https://open.spotify.com/playlist/1Iqn0mNNTSBFPTrgPY0e1j"
            target="_blank"
            rel="noreferrer"
          >
            Hindi hits · non-stop
          </a>
          <a
            className="underline decoration-cream/30 underline-offset-4"
            href="https://open.spotify.com/playlist/0I6mu7LlHfxuCKx7yevUGr"
            target="_blank"
            rel="noreferrer"
          >
            Top Bollywood 2026
          </a>
        </p>
        <p className="mt-4 text-cream/80">
          Main yeh gali chalata hoon. Har mohalle ki awaaz yahin set hoti hai. Naye scene judte rahenge.
        </p>
      </div>
    </div>
  );
}

function Motif({ motif }: { motif: Motif }) {
  if (motif === "steam") {
    return (
      <div className="steam absolute inset-0">
        <i style={{ left: "18%", animationDelay: "0s" }} />
        <i style={{ left: "48%", animationDelay: "1.2s" }} />
        <i style={{ left: "72%", animationDelay: "2.1s" }} />
      </div>
    );
  }
  if (motif === "stars") {
    const spots = [
      ["12%", "18%"],
      ["28%", "32%"],
      ["46%", "14%"],
      ["63%", "26%"],
      ["78%", "12%"],
      ["88%", "34%"],
      ["20%", "48%"],
      ["70%", "46%"],
    ];
    return (
      <div className="stars absolute inset-0">
        {spots.map(([left, top], star) => (
          <i key={star} style={{ left, top, animationDelay: `${star * 0.35}s` }} />
        ))}
      </div>
    );
  }
  if (motif === "scan") return <div className="scanlines absolute inset-0" />;
  if (motif === "dust") {
    return (
      <div className="dust absolute inset-0">
        {["10%", "24%", "40%", "58%", "73%", "86%"].map((left, bit) => (
          <i
            key={left}
            style={{ left, animationDelay: `${bit * 1.3}s`, animationDuration: `${9 + bit}s` }}
          />
        ))}
      </div>
    );
  }
  if (motif === "bokeh") {
    return (
      <div className="bokeh absolute inset-0">
        <i style={{ width: "28vw", height: "28vw", left: "8%", top: "18%" }} />
        <i style={{ width: "18vw", height: "18vw", right: "10%", top: "30%", animationDelay: "1s" }} />
        <i style={{ width: "22vw", height: "22vw", left: "40%", bottom: "18%", animationDelay: "0.4s" }} />
      </div>
    );
  }
  if (motif === "jali") return <div className="jali absolute inset-0" />;
  if (motif === "bulbs") {
    return (
      <div className="bulbs absolute inset-x-0 top-0">
        {Array.from({ length: 12 }, (_, bulb) => (
          <i key={bulb} />
        ))}
      </div>
    );
  }
  if (motif === "fluor") return <div className="fluor absolute inset-0" />;
  if (motif === "rain") return <div className="rain absolute inset-0" />;
  if (motif === "windows") {
    return (
      <div className="absolute inset-x-0 top-[18%] overflow-hidden">
        <div className="windows">
          {Array.from({ length: 8 }, (_, pane) => (
            <i key={pane} />
          ))}
        </div>
      </div>
    );
  }
  if (motif === "glow") {
    return (
      <div className="absolute inset-0 grid place-items-end justify-center pb-[18%]">
        <div className="diya" />
      </div>
    );
  }
  if (motif === "highway") {
    return (
      <>
        <div className="streaks absolute inset-x-0 top-[22%]">
          <i style={{ top: "10%", animationDelay: "0s" }} />
          <i style={{ top: "38%", animationDelay: "0.8s", width: "18vw" }} />
          <i style={{ top: "64%", animationDelay: "1.4s" }} />
        </div>
        <div className="road absolute inset-x-0" />
      </>
    );
  }
  if (motif === "flood") return <div className="flood absolute inset-0" />;
  return <div className="fog absolute inset-0" />;
}
