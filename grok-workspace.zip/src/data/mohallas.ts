export type Daypart = "subah" | "din" | "shaam" | "raat";

export type Motif =
  | "steam"
  | "stars"
  | "scan"
  | "dust"
  | "bokeh"
  | "jali"
  | "bulbs"
  | "fluor"
  | "rain"
  | "windows"
  | "glow"
  | "highway"
  | "flood"
  | "fog";

export type Program = { title: string; note: string };

export type Mohalla = {
  id: string;
  name: string;
  latin: string;
  freq: string;
  line: string;
  rj: string;
  city: string;
  horn: string;
  motif: Motif;
  mood: Record<Daypart, string>;
  programs: Program[];
};

export const mohallas: Mohalla[] = [
  {
    id: "chai",
    name: "चाय की चुस्की",
    latin: "Chai Ki Chuski",
    freq: "91.1",
    line: "Tapri ki cutting, bagal wali dukaan ka gossip, aur woh do minute jab duniya mute ho jaati hai.",
    rj: "RJ Adrak",
    city: "Indore",
    horn: "चाय गरम है",
    motif: "steam",
    mood: {
      subah: "Sarafa band, tapri khul gayi. Pehli cutting chal rahi hai.",
      din: "Dhoop tez hai, chai usse tez. Adrak extra.",
      shaam: "Band hone se pehle ek last round. Kulhad garam.",
      raat: "Sarafa ki bheed, steel bench, aur ek free refill.",
    },
    programs: [
      { title: "Adrak Cut", note: "Meethi maangoge, kadak milegi. Aaj kadak hai." },
      { title: "Tapri Report", note: "Bina naam ka gossip. Sirf mohalla jaanta hai." },
      { title: "Do Minute Ki Chai", note: "Break itna hi lamba hai. Pi lo." },
    ],
  },
  {
    id: "raat",
    name: "रात की बातें",
    latin: "Raat Ki Baatein",
    freq: "94.7",
    line: "Chhat pe chaadar, door kisi ka fan, aur woh baatein jo subah tak yaad nahi rehtin.",
    rj: "RJ Chhat",
    city: "Lucknow",
    horn: "धीरे बोलो",
    motif: "stars",
    mood: {
      subah: "Aakhri sitara. Azaan se pehle wali khamoshi.",
      din: "Raat yahan so rahi hai. Sham ko wapas aana.",
      shaam: "Bijli ki pehli lau. Chat par koi aa gaya.",
      raat: "Thandi hawa, shehar ki door ki roshni, dheemi baat.",
    },
    programs: [
      { title: "Chhat Session", note: "Volume kam. Pados wali neend mein hai." },
      { title: "Ek Hi Baat", note: "Jo din bhar nahi kahi, ab kaho." },
      { title: "Fan Ki Awaz", note: "Background mein sirf hawa. Bas." },
    ],
  },
  {
    id: "gali",
    name: "गली का रेडियो",
    latin: "Gali Ka Radio",
    freq: "98.3",
    line: "Purana transistor, thodi static, aur woh frequency jo poori gali sunti hai.",
    rj: "RJ Transistor",
    city: "Purani Dilli",
    horn: "गली जाग गई",
    motif: "scan",
    mood: {
      subah: "Doodh wala aa gaya. Radio abhi garam ho raha hai.",
      din: "Dukaan ke bahar speaker. Ek gaana, bees log.",
      shaam: "Andhere se pehle frequency pakad lo.",
      raat: "Static zyada, log kam. Radio phir bhi on hai.",
    },
    programs: [
      { title: "Static Report", note: "Antenna thoda idhar karo. Aa gayi." },
      { title: "Gali Bulletin", note: "Aaj ka halla, seedha speaker se." },
      { title: "Purana Band", note: "Jo set tha, wahi chal raha hai." },
    ],
  },
  {
    id: "nostalgia",
    name: "थोड़ी सी नॉस्टैल्जिया",
    latin: "Thodi Si Nostalgia",
    freq: "89.6",
    line: "Cassette ka click, woh wali shaam, aur gaana jo ab naam se nahi — scene se yaad aata hai.",
    rj: "RJ Rewind",
    city: "Kolkata",
    horn: "रीवाइंड",
    motif: "dust",
    mood: {
      subah: "Tram ki pehli bell. Chai abhi paper ke saath.",
      din: "Dhoop balcony pe. Koi purani diary khuli padi hai.",
      shaam: "Peeli bulb. Wahi rasta, thoda dheema.",
      raat: "Cassette khatam hone wali hai. Palat do.",
    },
    programs: [
      { title: "Side B", note: "Pencil se likha hua tracklist. Thoda dhundhla." },
      { title: "Woh Wali Shaam", note: "Saal yaad nahi. Mausam yaad hai." },
      { title: "Rewind", note: "Thoda peeche. Wahi line dobara." },
    ],
  },
  {
    id: "apni",
    name: "अपनी वाली वाइब",
    latin: "Apni Wali Vibe",
    freq: "102.4",
    line: "Koi theme nahi. Aaj jo dil kare — thoda loud, thoda personal, bilkul tumhari.",
    rj: "RJ Apna",
    city: "Goa",
    horn: "अपनी आवाज़",
    motif: "bokeh",
    mood: {
      subah: "Beach khaali. Speaker dheere, chai strong.",
      din: "Dhoop seedhi. Volume apne hisaab se.",
      shaam: "Sky pink ho rahi hai. Mix apna hai.",
      raat: "Lane band, beat khula. Koi dress code nahi.",
    },
    programs: [
      { title: "Apna Mix", note: "Request nahi lete. Yahan sab apna hai." },
      { title: "No Theme", note: "Genre ki tension chhod do." },
      { title: "Late Check-in", note: "Jo aaye, woh line mein hai." },
    ],
  },
  {
    id: "pink",
    name: "पिंक सिटी",
    latin: "Pink City",
    freq: "93.5",
    line: "Gulabi deewarein, shaam ki dhoop, aur woh chai jo haveli ke saaye mein thandi hoti hai.",
    rj: "RJ Gulabi",
    city: "Jaipur",
    horn: "गुलाल",
    motif: "jali",
    mood: {
      subah: "Deewar abhi thandi hai. Bazaar dheere khul raha hai.",
      din: "Dhoop gulabi. Chhaya dhundho, warna pighal jaoge.",
      shaam: "Sandstone garam. Chai ka round shuru.",
      raat: "Jali ke peeche diya. Shehar dheema, rang abhi bhi.",
    },
    programs: [
      { title: "Jali Ke Peeche", note: "Hawa pattern banati hai. Suno." },
      { title: "Gulabi Dhoop", note: "Shaam ka pehla ghanta. Sabse narm." },
      { title: "Haveli Hour", note: "Aangan khaali hai. Frequency bhari hai." },
    ],
  },
  {
    id: "baraat",
    name: "बारात का ढोल",
    latin: "Baraat Ka Dhol",
    freq: "106.2",
    line: "Gali band hai, dhol khula hai. Koi invitation nahi — pair khud beat pe aate hain.",
    rj: "RJ Dhol",
    city: "Amritsar",
    horn: "ढोल बजा",
    motif: "bulbs",
    mood: {
      subah: "Kal ki baraat ki thakaan. Dhol abhi bhi kaan mein hai.",
      din: "Tent lag raha hai. Ek side se speaker test.",
      shaam: "Bulb jagmag. Gali ek taraf se band.",
      raat: "Dhol full. Pados teen gali tak sun raha hai.",
    },
    programs: [
      { title: "Pehla Round", note: "Dhol wale ne haath garam kar liye." },
      { title: "Gali Band", note: "Car nahi, sirf pair. Side ho jao." },
      { title: "Last Song", note: "Woh wala, jispe sab line tod dete hain." },
    ],
  },
  {
    id: "office",
    name: "ऑफिस की चाय",
    latin: "Office Ki Chai",
    freq: "97.1",
    line: "AC ka hum, keyboard ki baarish, aur pantry wali chai jo hamesha thodi zyada ubaali hoti hai.",
    rj: "RJ Cabin",
    city: "Gurugram",
    horn: "मीटिंग है",
    motif: "fluor",
    mood: {
      subah: "Badge scan. Lift mein koi already thaka hua hai.",
      din: "Standup khatam. Asli kaam abhi.",
      shaam: "Floor aadha khaali. Ek aur chai, phir nikalte hain.",
      raat: "Sirf ek cabin jali hai. Deadline ka raag.",
    },
    programs: [
      { title: "Pantry Break", note: "Do minute. Teams pe 'brb' likh do." },
      { title: "Headphones On", note: "Open office. Duniya mute." },
      { title: "After 7", note: "Cafeteria band. Machine abhi chal rahi hai." },
    ],
  },
  {
    id: "monsoon",
    name: "मानसून गली",
    latin: "Monsoon Gali",
    freq: "95.0",
    line: "Tin shed pe baarish, geeli mitti, aur woh khushboo jispe auto ruk jaata hai.",
    rj: "RJ Baarish",
    city: "Kochi",
    horn: "छतरी भूल गए",
    motif: "rain",
    mood: {
      subah: "Baarish ruk-ruk ke. Chai ke upar lid zaroori.",
      din: "Sadak chamak rahi hai. Paani takle tak.",
      shaam: "Bijli ki lau, phir andhera, phir zor.",
      raat: "Tin pe tap-tap. Neend isi beat pe aayegi.",
    },
    programs: [
      { title: "Tin Shed", note: "Chat pe nahi — chhat ke neeche." },
      { title: "Geeli Mitti", note: "Pehli baarish ka smell, radio pe." },
      { title: "Ruk Ke Baras", note: "Lagta hai ruk gayi. Nahi ruki." },
    ],
  },
  {
    id: "local",
    name: "लोकल ट्रेन",
    latin: "Local Train",
    freq: "100.2",
    line: "Khidki se guzarta shehar, platform ki beep, aur woh jagah jo ek station ke liye tumhari hai.",
    rj: "RJ Platform",
    city: "Mumbai",
    horn: "अगला स्टेशन",
    motif: "windows",
    mood: {
      subah: "Dhakel narm nahi hoti. Pakad mazboot rakho.",
      din: "Thodi jagah. Khidki wali seat lottery hai.",
      shaam: "Office khatam, dabba bhar gaya. Earphone in.",
      raat: "Last locals. Shehar dheema, track abhi tez.",
    },
    programs: [
      { title: "Window Seat", note: "Agar mili, toh uthna mat." },
      { title: "Agla Station", note: "Naam suno. Utrna ya nahi — decide fast." },
      { title: "Ladies Side", note: "Yahan frequency thodi aur seedhi hai." },
    ],
  },
  {
    id: "mandir",
    name: "मंदिर की घंटी",
    latin: "Mandir Ki Ghanti",
    freq: "88.8",
    line: "Subah ki pehli ghanti, agarbatti, aur woh khamoshi jo aarti ke baad reh jaati hai.",
    rj: "RJ Ghanti",
    city: "Varanasi",
    horn: "घंटी बजी",
    motif: "glow",
    mood: {
      subah: "Ghat pe pehli lau. Paani abhi kaala, diya naya.",
      din: "Gali garam. Ghanti door se, clear.",
      shaam: "Aarti ki tayyari. Steps pe log ruk rahe hain.",
      raat: "Diyes dheere. Shehar jaagta hai, ghat shaant.",
    },
    programs: [
      { title: "Pehli Ghanti", note: "Ek baar. Phir do. Phir sab." },
      { title: "Aarti Ke Baad", note: "Bheed hati. Hawa mein dhoop nahi, dhuan." },
      { title: "Ghat FM", note: "Naam loud nahi. Bas tone." },
    ],
  },
  {
    id: "highway",
    name: "हाईवे रात",
    latin: "Highway Raat",
    freq: "104.8",
    line: "Window seat, NH 48, Delhi se Mumbai. Kaanon mein yeh mix, bahar guzarta shehar.",
    rj: "RJ Highway",
    city: "NH 48",
    horn: "हॉर्न ओके",
    motif: "highway",
    mood: {
      subah: "Dhaba dikha. Driver ne indicator lagaya.",
      din: "Dhoop windshield pe. Shehar beech-beech mein.",
      shaam: "Sodium lights shuru. Road lambi ho gayi.",
      raat: "All night, apni wali road par. Seat pakdo.",
    },
    programs: [
      { title: "Now Boarding", note: "Delhi nikal chuka. Agli chai 80 km." },
      { title: "Khidki Wali", note: "Truck ka horn door se aaya, pass hua." },
      { title: "Dhaba Break", note: "Das minute. Gaana band mat karna." },
    ],
  },
  {
    id: "cricket",
    name: "क्रिकेट गली",
    latin: "Cricket Gali",
    freq: "99.9",
    line: "Maidan nahi mila, toh gali hi ground hai. Ek tennis ball, do ite, aur poora mohalla umpire.",
    rj: "RJ Boundary",
    city: "Meerut",
    horn: "बाउंड्री",
    motif: "flood",
    mood: {
      subah: "Oos hai. Koi nahi aaya. Stumps abhi ghar mein.",
      din: "Dhoop seedhi. Over chhota, chillamchi badi.",
      shaam: "School bag gira, match shuru. Car aayi, toh field in.",
      raat: "Ek bulb, kaafi roshni. Last over bina light ke.",
    },
    programs: [
      { title: "Last Over", note: "Do run chahiye. Gali chhoti hai." },
      { title: "Car Aayi", note: "Field andar. Gaana bhi rukta hai, thodi der." },
      { title: "Tennis Ball FM", note: "Leather nahi. Awaz phir bhi crack ki." },
    ],
  },
  {
    id: "sardi",
    name: "दिल्ली की सर्दी",
    latin: "Dilli Ki Sardi",
    freq: "92.7",
    line: "Kohra, razai, aur woh seeti jo kisi ke pressure cooker se nahi — hawa se aati hai.",
    rj: "RJ Kohra",
    city: "Delhi",
    horn: "कोहरा गहरा",
    motif: "fog",
    mood: {
      subah: "Saans dikhti hai. Chai dono haathon se.",
      din: "Dhoop mil gayi toh lottery. Nahi mili toh theek.",
      shaam: "Kohra wapas. Streetlight gol-gol.",
      raat: "Razai ke bahar sirf haath. Radio andar.",
    },
    programs: [
      { title: "Kohra Report", note: "Visibility kam. Awaz saaf." },
      { title: "Razai FM", note: "Bahar mat jao. Yahi suno." },
      { title: "Doosri Chai", note: "Pehli khatam. Ketli phir se." },
    ],
  },
];

export const daypartLabel: Record<Daypart, string> = {
  subah: "Subah",
  din: "Din",
  shaam: "Shaam",
  raat: "Raat",
};

export function mohallaById(id: string | null | undefined) {
  return mohallas.find((m) => m.id === id) ?? mohallas[0];
}

export function istHour(ts: number) {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    hourCycle: "h23",
  }).formatToParts(ts);
  return Number(parts.find((p) => p.type === "hour")?.value ?? "0");
}

export function daypartFromHour(hour: number): Daypart {
  if (hour < 5 || hour >= 19) return "raat";
  if (hour < 11) return "subah";
  if (hour < 16) return "din";
  return "shaam";
}

export function formatIst(ts: number) {
  return new Intl.DateTimeFormat("en-IN", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "Asia/Kolkata",
  }).format(ts);
}
