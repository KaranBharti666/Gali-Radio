type Stop = () => void;

function makeNoise(ctx: AudioContext, kind: "white" | "pink" | "brown") {
  const length = ctx.sampleRate * 2;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let b0 = 0;
  let b1 = 0;
  let b2 = 0;
  let last = 0;
  for (let i = 0; i < length; i++) {
    const white = Math.random() * 2 - 1;
    if (kind === "white") {
      data[i] = white * 0.4;
    } else if (kind === "pink") {
      b0 = 0.997 * b0 + white * 0.029;
      b1 = 0.985 * b1 + white * 0.032;
      b2 = 0.95 * b2 + white * 0.05;
      data[i] = (b0 + b1 + b2) * 0.22;
    } else {
      last = (last + 0.02 * white) / 1.02;
      data[i] = last * 3.2;
    }
  }
  return buffer;
}

class Bus {
  stops: Stop[] = [];

  constructor(
    private ctx: AudioContext,
    private dest: AudioNode,
  ) {}

  private track(node: AudioNode) {
    this.stops.push(() => {
      try {
        node.disconnect();
      } catch {
        /* already stopped */
      }
    });
  }

  noise(
    buffer: AudioBuffer,
    gain: number,
    filter: { type: BiquadFilterType; freq: number; q: number },
    lfoHz = 0,
  ) {
    const src = this.ctx.createBufferSource();
    src.buffer = buffer;
    src.loop = true;
    const bi = this.ctx.createBiquadFilter();
    bi.type = filter.type;
    bi.frequency.value = filter.freq;
    bi.Q.value = filter.q;
    const g = this.ctx.createGain();
    g.gain.value = gain;
    src.connect(bi);
    bi.connect(g);
    g.connect(this.dest);
    src.start();
    this.stops.push(() => {
      try {
        src.stop();
      } catch {
        /* already stopped */
      }
    });
    this.track(src);
    this.track(bi);
    this.track(g);
    if (lfoHz > 0) {
      const lfo = this.ctx.createOscillator();
      const depth = this.ctx.createGain();
      lfo.frequency.value = lfoHz;
      depth.gain.value = filter.freq * 0.22;
      lfo.connect(depth);
      depth.connect(bi.frequency);
      lfo.start();
      this.stops.push(() => {
        try {
          lfo.stop();
        } catch {
          /* already stopped */
        }
      });
      this.track(lfo);
      this.track(depth);
    }
    return this;
  }

  tone(freq: number, type: OscillatorType, gain: number, lfoHz = 0, depth = 0) {
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.value = freq;
    const g = this.ctx.createGain();
    g.gain.value = gain;
    osc.connect(g);
    g.connect(this.dest);
    osc.start();
    this.stops.push(() => {
      try {
        osc.stop();
      } catch {
        /* already stopped */
      }
    });
    this.track(osc);
    this.track(g);
    if (lfoHz > 0) {
      const lfo = this.ctx.createOscillator();
      const amount = this.ctx.createGain();
      lfo.frequency.value = lfoHz;
      amount.gain.value = depth;
      lfo.connect(amount);
      amount.connect(osc.frequency);
      lfo.start();
      this.stops.push(() => {
        try {
          lfo.stop();
        } catch {
          /* already stopped */
        }
      });
      this.track(lfo);
      this.track(amount);
    }
    return this;
  }

  every(seconds: number, fire: (when: number) => void) {
    let alive = true;
    const id = window.setInterval(() => {
      if (!alive) return;
      fire(this.ctx.currentTime + 0.05);
    }, seconds * 1000);
    this.stops.push(() => {
      alive = false;
      window.clearInterval(id);
    });
    return this;
  }

  pattern(bpm: number, steps: Array<"kick" | "slap" | "rest">) {
    const step = 60 / bpm / 2;
    let next = this.ctx.currentTime + 0.06;
    let i = 0;
    let alive = true;
    const id = window.setInterval(() => {
      if (!alive) return;
      while (next < this.ctx.currentTime + 0.28) {
        const kind = steps[i % steps.length];
        if (kind === "kick") hitKick(this.ctx, this.dest, next);
        if (kind === "slap") hitSlap(this.ctx, this.dest, next);
        next += step;
        i += 1;
      }
    }, 60);
    this.stops.push(() => {
      alive = false;
      window.clearInterval(id);
    });
    return this;
  }
}

function hitKick(ctx: AudioContext, dest: AudioNode, when: number) {
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(160, when);
  osc.frequency.exponentialRampToValueAtTime(52, when + 0.12);
  g.gain.setValueAtTime(0.0001, when);
  g.gain.exponentialRampToValueAtTime(0.55, when + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, when + 0.18);
  osc.connect(g);
  g.connect(dest);
  osc.start(when);
  osc.stop(when + 0.2);
}

function hitSlap(ctx: AudioContext, dest: AudioNode, when: number) {
  const length = Math.floor(ctx.sampleRate * 0.08);
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
  const src = ctx.createBufferSource();
  src.buffer = buffer;
  const filter = ctx.createBiquadFilter();
  filter.type = "bandpass";
  filter.frequency.value = 1600;
  filter.Q.value = 0.7;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.28, when);
  g.gain.exponentialRampToValueAtTime(0.0001, when + 0.07);
  src.connect(filter);
  filter.connect(g);
  g.connect(dest);
  src.start(when);
  src.stop(when + 0.08);
}

function chirp(ctx: AudioContext, dest: AudioNode, when: number, freq: number) {
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(freq, when);
  osc.frequency.exponentialRampToValueAtTime(freq * 1.15, when + 0.08);
  g.gain.setValueAtTime(0.0001, when);
  g.gain.exponentialRampToValueAtTime(0.03, when + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, when + 0.12);
  osc.connect(g);
  g.connect(dest);
  osc.start(when);
  osc.stop(when + 0.14);
}

function bell(ctx: AudioContext, dest: AudioNode, when: number) {
  [523.25, 659.25, 783.99, 1046.5].forEach((freq, index) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    const peak = 0.07 / (index + 1);
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(peak, when + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 2.6);
    osc.connect(g);
    g.connect(dest);
    osc.start(when);
    osc.stop(when + 2.7);
  });
}

function bubble(ctx: AudioContext, dest: AudioNode, when: number) {
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = "sine";
  const freq = 500 + Math.random() * 700;
  osc.frequency.setValueAtTime(freq, when);
  osc.frequency.exponentialRampToValueAtTime(freq * 1.8, when + 0.09);
  g.gain.setValueAtTime(0.0001, when);
  g.gain.exponentialRampToValueAtTime(0.04, when + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, when + 0.12);
  osc.connect(g);
  g.connect(dest);
  osc.start(when);
  osc.stop(when + 0.14);
}

function crack(ctx: AudioContext, dest: AudioNode, when: number) {
  hitSlap(ctx, dest, when);
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = "triangle";
  osc.frequency.setValueAtTime(180, when);
  osc.frequency.exponentialRampToValueAtTime(70, when + 0.08);
  g.gain.setValueAtTime(0.12, when);
  g.gain.exponentialRampToValueAtTime(0.0001, when + 0.1);
  osc.connect(g);
  g.connect(dest);
  osc.start(when);
  osc.stop(when + 0.12);
}

function whistle(ctx: AudioContext, dest: AudioNode, when: number) {
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(880, when);
  osc.frequency.linearRampToValueAtTime(990, when + 0.4);
  g.gain.setValueAtTime(0.0001, when);
  g.gain.exponentialRampToValueAtTime(0.025, when + 0.08);
  g.gain.exponentialRampToValueAtTime(0.0001, when + 0.7);
  osc.connect(g);
  g.connect(dest);
  osc.start(when);
  osc.stop(when + 0.75);
}

export class GaliEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private bus: GainNode | null = null;
  private stops: Stop[] = [];
  private white: AudioBuffer | null = null;
  private pink: AudioBuffer | null = null;
  private brown: AudioBuffer | null = null;
  volume = 0.75;
  playing = false;
  builtFor: string | null = null;

  private async ensure() {
    if (!this.ctx) {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new Ctx();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.9;
      const comp = this.ctx.createDynamicsCompressor();
      comp.threshold.value = -16;
      comp.knee.value = 18;
      comp.ratio.value = 3.2;
      comp.attack.value = 0.008;
      comp.release.value = 0.22;
      this.master.connect(comp);
      comp.connect(this.ctx.destination);
      this.white = makeNoise(this.ctx, "white");
      this.pink = makeNoise(this.ctx, "pink");
      this.brown = makeNoise(this.ctx, "brown");
    }
    if (this.ctx.state === "suspended") await this.ctx.resume();
    return this.ctx;
  }

  async play(id: string) {
    await this.ensure();
    this.playing = true;
    if (this.builtFor !== id || !this.bus) this.swap(id);
    else this.ramp(this.volume);
  }

  pause() {
    this.playing = false;
    this.ramp(0);
  }

  setStation(id: string) {
    if (!this.playing || !this.ctx) {
      this.builtFor = null;
      return;
    }
    if (this.builtFor === id) return;
    this.swap(id);
  }

  setVolume(value: number) {
    this.volume = value;
    if (this.playing) this.ramp(value);
  }

  async horn() {
    const ctx = await this.ensure();
    const when = ctx.currentTime;
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const g = ctx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(240, when);
    osc.frequency.exponentialRampToValueAtTime(80, when + 0.42);
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(1400, when);
    filter.frequency.exponentialRampToValueAtTime(220, when + 0.4);
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(0.22, when + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 0.48);
    osc.connect(filter);
    filter.connect(g);
    g.connect(this.master!);
    osc.start(when);
    osc.stop(when + 0.5);
  }

  private ramp(value: number) {
    if (!this.ctx || !this.bus) return;
    const now = this.ctx.currentTime;
    const current = this.bus.gain.value;
    this.bus.gain.cancelScheduledValues(now);
    this.bus.gain.setValueAtTime(current, now);
    this.bus.gain.linearRampToValueAtTime(value, now + 0.08);
  }

  private swap(id: string) {
    const ctx = this.ctx;
    const master = this.master;
    if (!ctx || !master || !this.white || !this.pink || !this.brown) return;
    const dying = this.stops;
    const dyingBus = this.bus;
    this.stops = [];
    const next = ctx.createGain();
    next.gain.setValueAtTime(0.0001, ctx.currentTime);
    next.gain.linearRampToValueAtTime(this.playing ? this.volume : 0.0001, ctx.currentTime + 0.55);
    next.connect(master);
    this.bus = next;
    this.builtFor = id;
    const bed = new Bus(ctx, next);
    voice(id, bed, ctx, next, { white: this.white, pink: this.pink, brown: this.brown });
    this.stops = bed.stops;
    if (dyingBus) {
      dyingBus.gain.cancelScheduledValues(ctx.currentTime);
      dyingBus.gain.setValueAtTime(Math.max(dyingBus.gain.value, 0.0001), ctx.currentTime);
      dyingBus.gain.linearRampToValueAtTime(0.0001, ctx.currentTime + 0.45);
      window.setTimeout(() => {
        dying.forEach((fn) => fn());
        try {
          dyingBus.disconnect();
        } catch {
          /* already gone */
        }
      }, 520);
    }
  }
}

type Buffers = { white: AudioBuffer; pink: AudioBuffer; brown: AudioBuffer };

function voice(id: string, bed: Bus, ctx: AudioContext, dest: AudioNode, buf: Buffers) {
  switch (id) {
    case "chai":
      bed
        .noise(buf.brown, 0.16, { type: "lowpass", freq: 180, q: 0.6 })
        .noise(buf.pink, 0.05, { type: "bandpass", freq: 1300, q: 0.8 }, 0.12)
        .tone(196, "sine", 0.03)
        .every(1.4, (when) => bubble(ctx, dest, when));
      break;
    case "raat":
      bed
        .tone(196, "sine", 0.02)
        .tone(392, "sine", 0.012)
        .noise(buf.brown, 0.07, { type: "lowpass", freq: 140, q: 0.5 })
        .every(1.1, (when) => chirp(ctx, dest, when, 4200 + Math.random() * 600));
      break;
    case "gali":
      bed
        .noise(buf.white, 0.035, { type: "bandpass", freq: 1800, q: 3.2 }, 0.4)
        .noise(buf.brown, 0.12, { type: "lowpass", freq: 110, q: 0.4 })
        .tone(880, "square", 0.004);
      break;
    case "nostalgia":
      bed
        .tone(220, "triangle", 0.04, 0.25, 6)
        .tone(277.18, "triangle", 0.018, 0.18, 4)
        .noise(buf.pink, 0.045, { type: "lowpass", freq: 900, q: 0.4 });
      break;
    case "apni":
      bed
        .tone(220, "sawtooth", 0.012)
        .tone(277.18, "sawtooth", 0.01)
        .tone(329.63, "triangle", 0.014)
        .noise(buf.pink, 0.03, { type: "lowpass", freq: 700, q: 0.6 }, 0.5)
        .pattern(100, ["kick", "rest", "slap", "rest", "kick", "slap", "rest", "slap"]);
      break;
    case "pink":
      bed
        .tone(196, "sine", 0.03)
        .tone(246.94, "sine", 0.02)
        .tone(293.66, "triangle", 0.016)
        .noise(buf.pink, 0.04, { type: "bandpass", freq: 640, q: 0.5 }, 0.08);
      break;
    case "baraat":
      bed
        .noise(buf.pink, 0.05, { type: "bandpass", freq: 900, q: 0.5 }, 0.3)
        .tone(98, "sine", 0.04)
        .pattern(112, ["kick", "slap", "kick", "slap", "slap", "kick", "slap", "rest"]);
      break;
    case "office":
      bed
        .tone(60, "sine", 0.03)
        .tone(120, "sine", 0.015)
        .noise(buf.white, 0.012, { type: "highpass", freq: 5000, q: 0.4 })
        .every(7.5, (when) => chirp(ctx, dest, when, 880));
      break;
    case "monsoon":
      bed
        .noise(buf.white, 0.11, { type: "bandpass", freq: 2200, q: 0.35 })
        .noise(buf.brown, 0.1, { type: "lowpass", freq: 90, q: 0.4 }, 0.08)
        .every(9, (when) => {
          const osc = ctx.createOscillator();
          const g = ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(48, when);
          g.gain.setValueAtTime(0.0001, when);
          g.gain.exponentialRampToValueAtTime(0.2, when + 0.2);
          g.gain.exponentialRampToValueAtTime(0.0001, when + 1.6);
          osc.connect(g);
          g.connect(dest);
          osc.start(when);
          osc.stop(when + 1.7);
        });
      break;
    case "local":
      bed
        .noise(buf.brown, 0.14, { type: "lowpass", freq: 100, q: 0.5 })
        .pattern(126, ["slap", "rest", "kick", "rest"])
        .every(8, (when) => {
          chirp(ctx, dest, when, 740);
          chirp(ctx, dest, when + 0.18, 988);
        });
      break;
    case "mandir":
      bed
        .tone(174.61, "sine", 0.028)
        .tone(261.63, "sine", 0.016)
        .noise(buf.brown, 0.04, { type: "lowpass", freq: 200, q: 0.4 })
        .every(6.5, (when) => bell(ctx, dest, when));
      break;
    case "highway":
      bed
        .tone(55, "sine", 0.05)
        .tone(82.4, "triangle", 0.03)
        .noise(buf.pink, 0.05, { type: "bandpass", freq: 480, q: 0.7 }, 0.07)
        .noise(buf.white, 0.02, { type: "bandpass", freq: 1600, q: 1.4 }, 0.15);
      break;
    case "cricket":
      bed
        .noise(buf.pink, 0.07, { type: "bandpass", freq: 780, q: 0.6 }, 0.25)
        .tone(70, "sine", 0.02)
        .every(4.2, (when) => {
          if (Math.random() > 0.35) crack(ctx, dest, when);
        });
      break;
    case "sardi":
      bed
        .noise(buf.brown, 0.1, { type: "lowpass", freq: 220, q: 0.35 }, 0.06)
        .tone(311, "sine", 0.008)
        .every(11, (when) => whistle(ctx, dest, when));
      break;
    default:
      bed.noise(buf.pink, 0.05, { type: "lowpass", freq: 400, q: 0.5 });
  }
}

const scope = globalThis as { __gali?: GaliEngine };

export function getEngine() {
  if (!scope.__gali) scope.__gali = new GaliEngine();
  return scope.__gali;
}
