import { createFileRoute } from "@tanstack/react-router";
import { RadioGali } from "@/components/gali/radio-gali";

export const Route = createFileRoute("/")({ component: RadioGali });
